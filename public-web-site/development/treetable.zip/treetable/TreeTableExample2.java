package treetable;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.table.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;

/**
 * Assembles the UI. The UI consists of a JTreeTable and a status label.
 * As nodes are loaded by the FileSystemModel2 or 3(FMT), in a background thread,
 * the status label updates as well as the renderer to draw the node that
 * is being loaded differently.
 *
 * @author Scott Violet
 * @author Philip Milne
 */
public class TreeTableExample2 {
	/** Number of instances of TreeTableExample2. */
	protected static int         ttCount;
	/** Frame containing everything. */
	protected JFrame             frame;
	/** Path created with. */
	protected String             path;
	
	
	
	/** Model for the JTreeTable. */
	protected FileSystemModel3    model;
	/** Used to represent the model. */
	protected JTreeTable         treeTable;
	
	
	public TreeTableExample2(String path) {
		this.path = path;	
		frame = createFrame();
		Container      cPane = frame.getContentPane();
		
		ttCount++;
		
		//--------------
		model = new FileSystemModel3();	//java.io.File.separator
		model.reloadChildren(model.getRoot());
		treeTable = createTreeTable();
		cPane.add(new JScrollPane(treeTable));
		//--------------
		
		frame.pack();
		frame.show();
	}
	
	/**
	 * Creates and returns the instanceof JTreeTable that will be used.
	 * This also creates, but does not start, the Timer that is used to
	 * update the display as files are loaded.
	 */
	protected JTreeTable createTreeTable() {
		JTreeTable       treeTable = new JTreeTable(model);
		
		return treeTable;
	}
	
	/**
	 * Creates the JFrame that will contain everything.
	 */
	protected JFrame createFrame() {
		JFrame       retFrame = new JFrame("TreeTable II");
		
		retFrame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				if (--ttCount == 0) {
					System.exit(0);
				}
			}
		});
		return retFrame;
	}
	
	public static void main(String[] args) {
		if (args.length > 0) {
			for (int counter = args.length - 1; counter >= 0; counter--) {
				new TreeTableExample2(args[counter]);
			}
		}
		else {
			String            path;
			
			try {
				path = System.getProperty("user.home");
				if (path != null) {
					new TreeTableExample2(path);
				}
			}
			catch (SecurityException se) {
				path = null;
			}
			if (path == null) {
				System.out.println("Could not determine home directory");
			}
		}
	}
}

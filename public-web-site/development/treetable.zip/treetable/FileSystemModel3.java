package treetable;

import java.io.IOException;
import java.io.File;
import java.util.Date;
import java.util.Stack;
import javax.swing.SwingUtilities;
import javax.swing.tree.TreePath;

import treetable.FileSystemModel2.FileNode;

import java.util.*;


/**
 * FileSystemModel2 is a TreeTableModel representing a hierarchical file
 * system.<p>
 * This will recursively load all the children from the path it is
 * created with. The loading is done with the method reloadChildren, and
 * happens in another thread. The method isReloading can be invoked to check
 * if there are active threads. The total size of all the files are also
 * accumulated.
 * <p>
 * By default links are not descended. java.io.File does not have a way
 * to distinguish links, so a file is assumed to be a link if its canonical
 * path does not start with its parent path. This may not cover all cases,
 * but works for the time being.
 * <p>Reloading happens such that all the files of the directory are
 * loaded and immediately available. The background thread then recursively
 * loads all the files of each of those directories. When each directory has
 * finished loading all its sub files they are attached and an event is
 * generated in the event dispatching thread. A more ambitious approach
 * would be to attach each set of directories as they are loaded and generate
 * an event. Then, once all the direct descendants of the directory being
 * reloaded have finished loading, it is resorted based on total size.
 * <p>
 * While you can invoke reloadChildren as many times as you want, care
 * should be taken in doing this. You should not invoke reloadChildren
 * on a node that is already being reloaded, or going to be reloaded
 * (meaning its parent is reloading but it hasn't started reloading
 * that directory yet). If this is done odd results may
 * happen. FileSystemModel2 does not enforce any policy in this manner,
 * and it is up to the user of FileSystemModel2 to ensure it doesn't
 * happen.
 * 
 * @version 1.12 05/12/98
 * @author Philip Milne
 * @author Scott Violet
 */

public class FileSystemModel3 extends AbstractTreeTableModel {
	
    public static class Node implements Cloneable {
        public static Node createNodeTree() {
            Node aNode= null;
            Node topNode= null;
            {
                String[] children= {"one", "two", "three"};
                List nodes= new ArrayList();
                
                aNode= new Node(21, "Clemens", Arrays.asList(children), (List)null);
            }
            {
                Node[] subNodes= {(Node)aNode.clone(), (Node)aNode.clone(), (Node)aNode.clone()};
                String[] children= {"four", "five"};
                topNode= new Node(1,"one", Arrays.asList(children), Arrays.asList(subNodes));
            }
            return topNode;
        }
        
        public int value;
        public String name;
        
        public List children= new ArrayList();
        public List subNodes= new ArrayList();
        
        public Node(int val, String name, List children, List subNodes) {
            this.value= val;
            this.name= name;
            if(null != children) {
                this.children= children;
            }
            if(null != subNodes) {
                this.subNodes= subNodes;
            }
        }
        
        public Object clone() {
            Node newNode= new Node(this.value, this.name.trim(), Arrays.asList(this.children.toArray()), Arrays.asList(this.subNodes.toArray()));
            return newNode;
        }
    }
    
	// Names of the columns.
	static protected String[]  cNames = {"ColOne", "ColTwo", "ColThree", "ColFour"};
	
	// Types of the columns.
	static protected Class[]  cTypes = { TreeTableModel.class,
		Node.class, Integer.class,
		String.class};
	
	// The the returned file length for directories. 
	public static final Integer      ZERO = new Integer(0); 
	
	
	/** True if the receiver is valid, once set to false all Threads
	 * loading files will stop. */
	protected boolean                isValid;
	
	/** Returns true if links are to be descended. */
	protected boolean                descendLinks;
	
	public static int nodes= 30;
	
	
	/**
	 * Creates a FileSystemModel2 rooted at File.separator, which is usually
	 * the root of the file system. This does not load it, you should invoke
	 * <code>reloadChildren</code> with the root to start loading.
	 */
	public FileSystemModel3() {
        super((Object)Node.createNodeTree());
	}
	
	/**
	 * Creates a FileSystemModel2 with the root being <code>rootPath</code>.
	 * This does not load it, you should invoke
	 * <code>reloadChildren</code> with the root to start loading.
	 *
	public FileSystemModel3(String rootNum) { 
		super(null);
		isValid = true;
		root = new Integer(4*rootNum*);
		System.out.println("3Constructor");
	}*/
	
	//
	// The TreeModel interface
	//
	
	/**
	 * Returns the number of children of <code>node</code>.
	 */
	public int getChildCount(Object node) { 
		/*Object[] children = getChildren(node); 
		int count= (children == null) ? 0 : children.length;
		System.out.println(String.valueOf(count)+ " getChildCount");*/
        if(node instanceof Node) {
            Node aNode= (Node)node;
            int subs= aNode.subNodes.size();
            if(subs == 0) {
                return aNode.children.size();
            } else {
                return aNode.subNodes.size();
            }
        } else {
            return 0;
        }
	}
	
	/**
	 * Returns the child of <code>node</code> at index <code>i</code>.
	 */
	public Object getChild(Object node, int i) { 
        if(node instanceof Node) {
            Node aNode= (Node)node;
            
            if(aNode.subNodes.size() == 0) {
                return aNode.children.get(i);
            } else {
                return aNode.subNodes.get(i);
            }
        } else {
            return null;
        }
        
        /*Object[] children= getChildren(node);
        if(children.length > i) {
            if(null == children) {
                System.out.println("NULL!");
                return null;
            } else {
                System.out.println("getChild:"+ children.length);
                return children[i]; 
            }
        } else {
            System.out.println("out of bounds");
            return null;
        }*/
	}
	
	/**
	 * Returns true if the passed in object represents a leaf, false
	 * otherwise.
	 */
	public boolean isLeaf(Object node) {
		/*boolean retVal= ((Integer)node).intValue() > 1;
		//System.out.println(retVal ? "IsLeaf" : "notLeaf");
		return retVal;*/
        return !(node instanceof Node);
	}
	
	//
	//  The TreeTableNode interface. 
	//
	
	/**
	 * Returns the number of columns.
	 */
	public int getColumnCount() {
		return cNames.length;
	}
	
	/**
	 * Returns the name for a particular column.
	 */
	public String getColumnName(int column) {
		return cNames[column];
	}
	
	/**
	 * Returns the class for the particular column.
	 */
	public Class getColumnClass(int column) {
		return cTypes[column];
	}
	
	/**
	 * Returns the value of the particular column.
	 */
	public Object getValueAt(Object node, int column) {
        if (node instanceof Node)
        {
            Node aNode = (Node) node;

            System.out.println("getValueAt:" + column);

            try
            {
                switch (column)
                {
                    case 0:
                        return aNode;
                    case 1:
                        return new Integer(aNode.value);
                    case 2:
                        return aNode.name;
                    case 3:
                        return aNode.name;
                }
            } catch (SecurityException se)
            {
            }
        } else {
            return node;
        }
		return null; 
	}
	
	//
	// Some convenience methods. 
	//
	
	/**
	 * If <code>newValue</code> is true, links are descended. Odd results
	 * may happen if you set this while other threads are loading.
	 */
	public void setDescendsLinks(boolean newValue) {
		System.out.println("setDescendsLinks");
		descendLinks = newValue;
	}
	
	/**
	 * Returns true if links are to be automatically descended.
	 */
	public boolean getDescendsLinks() {
		System.out.println("getDescendsLinks");
		return descendLinks;
	}
	
	protected Object[] getChildren(Object node) {
        List list= new ArrayList(0);
		/*int val= ((Integer)node).intValue();
		val++;
		int amount= val;
		if(amount > 6)	amount= 0;
		
		
		List list= new ArrayList(0);
		nodes--;
		if(nodes == 0) {
			nodes= 30;
			amount= 0;
		}
		for(int i= 0; i <= amount; i++) {
			list.add(new Integer(val));
		}
		*/
        
        if (node instanceof Node)
        {
            Node aNode = (Node) node;
            if(aNode.subNodes.size() == 0) {
                list= aNode.children;
            } else {
                list= aNode.subNodes;
            }
        }        
		System.out.println(String.valueOf(list.size())+ " getChilden");

		return list.toArray();
	}
	
	/**
	 * Reloads the children of the specified node.
	 */
	public void reloadChildren(Object node) {
		System.out.println("reloadChildren");
		//this.root= new Integer(1);
	}
	
	
	protected static Object[] EMPTY_CHILDREN = new Object[0];
}

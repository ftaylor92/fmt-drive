package treetable;

import java.util.*;

public class TreeData {
	public List/*<String>*/ rowData= new ArrayList/*<String>*/();;
	public List/*<TreeData>*/ children= new ArrayList/*<TreeData>*/();
	
	public TreeData() {
		
	}
	
	public TreeData(List/*<String>*/ rowData) {
		this.rowData= rowData;
	}
	
	public TreeData(List/*<String>*/ rowData, List/*<TreeData>*/ children) {
		this.rowData= rowData;
		this.children= children;
	}
	
	public static List/*<TreeData>*/ createTreeData() {
		String[] aRow= {"Type", "ID", "X", "Y"};
		String[] aSubRow= {"subtype", "sID", "x", "y"};
		String[] aSubSubRow= {"subtype", "sID"};
		
		List row/*<String>*/= Arrays.asList(aRow);
		List subRow/*<String>*/= Arrays.asList(aSubRow);
		List subSubRow/*<String>*/= Arrays.asList(aSubSubRow);
		
		List/*<TreeData>*/ all= new ArrayList/*<TreeData>*/();
		
		TreeData one= new TreeData(row);
		TreeData two= new TreeData(subRow);
		TreeData three= new TreeData(subSubRow);
		two.children.add(three);
		two.children.add(three);
		
		one.children.add(two);
		one.children.add(two);
		
		all.add(one);
		all.add(one);
		
		return all;
	}
}

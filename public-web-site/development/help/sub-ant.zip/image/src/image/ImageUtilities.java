package image;

import java.io.File;
import java.lang.InterruptedException;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.Component;
import java.awt.Graphics2D;
import java.awt.MediaTracker;
import java.io.FileOutputStream;
import java.awt.Component;
//import javax.imageio.ImageIO;
import com.sun.image.codec.jpeg.JPEGImageEncoder;
import com.sun.image.codec.jpeg.JPEGCodec;

/**
 * Image Utility functions
 **/
public class ImageUtilities {
	private static final Component sComponent= new Component() {};	
	private static final MediaTracker sTracker= new MediaTracker(sComponent);	
	private static int sID= 0;	
	private ImageUtilities() {}
	
	/**
	 * waits for an image to load fully into memory
	 * @param img image to wait for
	 * @return whether image loaded successfully
	 **/
	public static boolean waitForImage(Image img) {
		int id;
		synchronized(sComponent) { id= sID++; }
		sTracker.addImage(img, id);
		try{ sTracker.waitForID(id);
		} catch(InterruptedException ex) { return false; }
		if(sTracker.isErrorID(id)) { return false; }
		
		return true;
	}
	
	/**
	 * converts Image into BufferedImage
	 * @param img image to convert into a BufferedImage
	 * @return newly created BufferedImage
	 **/
	public static BufferedImage makeBufferedImage(Image img) {
		return makeBufferedImage(img, BufferedImage.TYPE_INT_RGB);
	}
	
	/**
	 * converts Image into BufferedImage
	 * @param img image to convert into a BufferedImage
	 * @param imageType type of BufferedImage to create
	 * @return newly created BufferedImage
	 **/
	public static BufferedImage makeBufferedImage(Image img, int imageType) {
		if(waitForImage(img) == false) { return null; }
		
		BufferedImage bImg= new BufferedImage(img.getWidth(null), img.getHeight(null), imageType);
		Graphics2D g2= bImg.createGraphics();
		g2.drawImage(img, null, null);
		
		return bImg;
	}
	
	/**
	 * writes image to file
	 * @param img image to write out to filePath
	 * @param filePath filePath to write image to
	 **/
	public static void writeImage(Image img, String filePath/*, int imageType*/) {
		BufferedImage bImg= makeBufferedImage(img/*, imageType*/);
		writeImage(bImg, filePath);
	}

	/**
	 * writes image to file
	 * @param bImg image to write out to filePath
	 * @param filePath filePath to write image to
	 **/
	public static void writeImage(BufferedImage bImg, String filePath) {
		try {
			FileOutputStream fos = new FileOutputStream(filePath);
			JPEGImageEncoder jpeg = JPEGCodec.createJPEGEncoder(fos);
			jpeg.encode(bImg);
			fos.flush();
			fos.close();
		} catch(Exception ex) {
			System.err.println(ex);
		}
	}
}
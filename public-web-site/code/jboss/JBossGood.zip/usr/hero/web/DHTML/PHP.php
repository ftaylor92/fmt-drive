<HTML>
<HEAD><TITLE>PHP Test</TITLE>
</HEAD>
<BODY>
	<?
	   $link=mysql_connect("localhost",$_POST['jboss'],$_POST['matt88']) or die("Connect Error: ".mysql.error());
	   print "Successfully Connected.\n";
	   mysql_close($link);
	?>
	<?php echo "Hello World<p>"; ?>
</BODY>
</HTML>
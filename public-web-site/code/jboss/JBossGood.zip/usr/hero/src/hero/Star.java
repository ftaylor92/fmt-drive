package hero;

import java.awt.Point;
import java.awt.Dimension;
import java.awt.Graphics2D;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.applet.Applet;

/**
 * represents a Chinese Throwing Star game piece
 * @author  TaylorFM
 */
public class Star extends ScreenItem {    
    /** Creates a new instance of Star 
     * @param game Game this piece is involved.
     **/
    public Star(Game game) {
        super(game, new Point(0,0), new Dimension(26, 26), new Point(13,13), new Dimension(10,8), POINTS.STARSCORE);
        DIRECTION direction= Util.randomDirection();
        
        this.direction= direction;
        
        switch(direction) {
            case LEFT:
                this.place= new Point(game.view.content.getWidth(), Util.random.nextInt(game.view.content.getHeight()));
                break;
            case RIGHT:
                this.place= new Point(0, Util.random.nextInt(game.view.content.getHeight()));
                break;
            case UP:
                this.place= new Point(Util.random.nextInt(game.view.content.getWidth()), game.view.content.getHeight());
                break;
            case DOWN:
                this.place= new Point(Util.random.nextInt(game.view.content.getWidth()), 0);
                break;
                
        }
        
        /* try {
            setIcons("star");
        } catch (IOException ex) {
            System.out.println(ex);
        } */

        setIcon();
    }
    
    public void setIcon() {
        icon= icons.get(step%2);
    }
    
    void setIcons(String type, Applet webApp) throws IOException {
        icons.add(ImageIO.read(new File("images/bonus/"+type+"1.gif")));
        icons.add(ImageIO.read(new File("images/bonus/"+type+"2.gif")));
    }
    
    public void kill() {
        alive= false;
    }
    
    boolean canKill() {
        return true;
    }
    
    boolean canDie() {
        return true;
    }
    
    public boolean kills(ScreenItem man) {
        return false;
    }
    
    public void draw(Graphics2D screen) {
        super.draw(screen);
        
        screen.drawString(this.place.x+","+this.place.y, this.place.x, this.place.y);
    }
}

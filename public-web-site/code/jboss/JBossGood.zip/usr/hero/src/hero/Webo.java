package hero;

import javax.swing.JApplet;
import javax.swing.RootPaneContainer;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Color;

/**
 *
 * @author TaylorFM
 */
public class Webo extends JApplet {
    public Container            content;
    public RootPaneContainer    parent;
    
    /** Creates a new instance of Webo */
    public Webo() {
    }
    
    public void init() {
        parent= this;
        content= getContentPane();
        System.out.println("JApplet.init() called");
        content.setBackground(Color.RED);
        
        View.splashScreen(content, this);
    }
    
    public void start() {
        System.out.println("JApplet.start() called");
    }
    
    public void stop() {
    }
    
    public void destroy() {
    }
    
    public void paint(Graphics g) {
        super.paint(g);
        
        System.out.println("JApplet.Paint() called");
        
        g.drawString("Bill", 10, 10);
    }
}

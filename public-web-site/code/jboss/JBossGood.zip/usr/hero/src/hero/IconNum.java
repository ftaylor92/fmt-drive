package hero;

/**
 * @ deprecated - change this, compile, then delete class
 * for Dimensions/offsets of icons.
 * and places for Icons in List.
 * @author  TaylorFM
 */
public abstract class IconNum {

    public final static int H_INFRONT_BUFFER= 10;
    public final static int V_INFRONT_BUFFER= 8;
    
    //public final static int ICON_HEIGHT= 90;
    //public final static int ICON_WIDTH= 90;
    //public final static int ICON_WIDTH_DIV2= 45;

    /* Borders */
    public final static int TILESIZE=	32;
    public final static int BORDERSIZE=	11;
    public final static int	SCOREHEIGHT=	16;
    public final static int	TOPHT=		SCOREHEIGHT+ BORDERSIZE;

    /*defIcons.h defines all icon places in arrays*/
    public final static int	ANUM=	0;
    public final static int	WNUM=	4;
    public final static int	WNUM2=	0;
    public final static int	SNUM=	12;				
    public final static int	SNUM2=	8;				
    public final static int	PNUM=	16;
    public final static int	FNUM=	20;
    public final static int	JNUM=	24;
    public final static int	ALNUM=	0;
    public final static int	WLNUM=	4;
    public final static int	SLNUM=	12;				
    public final static int	PLNUM=	16;
    public final static int	FLNUM	=20;
    public final static int	JLNUM=	24;
    public final static int	AUNUM=	1;
    public final static int	WUNUM=	5;
    public final static int	SUNUM=	13;				
    public final static int	PUNUM=	17;
    public final static int	FUNUM=	21;
    public final static int	JUNUM=	25;
    public final static int	ARNUM	=2;
    public final static int	WRNUM=	6;
    public final static int	SRNUM	=14;				
    public final static int	PRNUM	=18;
    public final static int	FRNUM=	22;
    public final static int	JRNUM=	26;
    public final static int	ADNUM=	3;
    public final static int	WDNUM=	7;
    public final static int	SDNUM	=15;				
    public final static int	PDNUM=	19;
    public final static int	FDNUM=	23;
    public final static int	JDNUM=	27;
    public final static int	DEADNUM	=			28;
    public final static int	DROWNEDNUM=			29;
    public final static int	ARROWDEADNUM=		4;
    public final static int	STARDEADNUM	=		30;
    public final static int	ARCHERDEADNUM	=	12;
    public final static int	SWORDSMENDEADNUM=	16;
    public final static int	WARLORDDEADNUM	=	8;
    public final static int	PRINCESSHAPPYNUM=	12;

    public final static int	FIRSTARROWNUM	=	0;
    public final static int	FIRSTSHAFTNUM	=	0;
    public final static int	FIRSTTRIDENTNUM	=	0;
    public final static int	FIRSTSTABBINGNUM=	12;

    public final static int	BLUEBALLNUM	=	0;
    public final static int	REDBALLNUM	=	1;
    public final static int	MULTIPLIERNUM=	8;
    public final static int	POINTSNUM=		7;
    public final static int	STARNUM	=		16;
    public final static int	HYPERSPACENUM=	20;
    public final static int	ADVANCELEVELNUM	=24;
    public final static int	YINYANGNUM=		12;
    public final static int	BLACKHOLENUM=	25;
    public final static int	BONUSBALLNUM=	2;
    public final static int	FREEZENUM=		29;
    public final static int	RESSURECTIONNUM=	31;
    public final static int	REANIMATIONNUM=	32;
    public final static int	FIRECRACKERNUM=	33;
    public final static int	EXPLOSIONNUM=	34;

    public final static int	WARBALLNUM=	9;

        /* Human Icon Dimensions */
        public final static int	WARLORDR=	64;
        public final static int	WARLORDB=	116;

        public final static int	BONUSBALLH=	25;
        public final static int	BONUSBALLW=	25;

        public final static int	H_HUMAN= 38;
        public final static int V_HUMAN= 78;

        public final static int	SHAFTLEN=	25;
        public final static int SHAFTW	=	9;
        public final static int	TRIDENTLEN=	25;
        public final static int	TRIDENTW=	9;

        public final static int	HDIE=		2;
        public final static int	VDIE=		10;
        public final static int	HDROWN	=	3;
        public final static int	VDROWN=		21;

        public final static int	HFH=			-1;
        public final static int	VFH=			10;
        public final static int	HFV=			0;
        public final static int VFV	=		10;

        public final static int	HJH=			-9;
        public final static int	VJH=			10;
        public final static int	HJV=			0;
        public final static int	VJV=			0;

        /*Pre Brian Settings
        public final static int	HFH			(-5)
        public final static int	VFH			12
        public final static int	HFV			0
        public final static int VFV			13

        public final static int	HJH			(-9)
        public final static int	VJH			10
        public final static int	HJV			0
        public final static int	VJV			7*/

        public final static int	HFHEIGHT=	15;
        public final static int	VFHEIGHT=	9;
        public final static int	HJHEIGHT=	20;
        public final static int	VJHEIGHT=	10;

        public final static int	TUH=		5;
        public final static int	TUV=		9;
        public final static int	TUHO=	0;
        public final static int	TUVO=	-47;
        public final static int	TUHO2=	0;
        public final static int	TUVO2=	-19;
        public final static int	TDH=		3;
        public final static int	TDV=		9;
        public final static int	TDHO=	0;
        public final static int	TDVO=	48;
        public final static int	TDHO2=	0;
        public final static int	TDVO2=	27;
        public final static int	TRH=		-7;
        public final static int	TRV=		17;
        public final static int	TRHO=	31;
        public final static int	TRVO=	0;
        public final static int	TRHO2=	23;
        public final static int	TRVO2=	0;
        public final static int	TLH=		-7;
        public final static int	TLV=		17;
        public final static int	TLHO=	-33;
        public final static int	TLVO=	0;
        public final static int	TLHO2=	-21;
        public final static int	TLVO2=	0;
        public final static int	SUH=		6;
        public final static int	SUV=		10;
        public final static int	SUHO	=0;
        public final static int	SUVO=	9;
        public final static int	SDH=		8;
        public final static int	SDV=		6;
        public final static int	SDHO=	0;
        public final static int	SDVO	=-6;
        public final static int	SLH=		12;
        public final static int	SLV=		7;
        public final static int	SLHO=	12;
        public final static int	SLVO=	0;
        public final static int	SRH=		12;
        public final static int	SRV=		7;
        public final static int	SRHO=	-11;
        public final static int	SRVO=	0;
}

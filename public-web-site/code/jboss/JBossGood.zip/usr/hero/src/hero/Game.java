package hero;

import java.util.List;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.Color;
import java.awt.Point;
import java.io.Serializable;
import java.io.IOException;

import hero.persistent.KeyModify;
import hero.persistent.NewGame;

/**
 * represents an entire Quarter/Play of Chinese Hero.
 *	@author	ftaylor
 */
public class Game implements Serializable	{
        Level level;
        Timer cycle;
        /** How fast each loop/step should show **/
        public final static int GAME_SPEED= 256;
        boolean paused= true;
        /**list of Players in current game**/
	 public final List<Player>	players=	new ArrayList<Player>();
	 /**list of Enemies in current game**/
         public List<Enemy> enemies= new	ArrayList<Enemy>();
	 /**list of objects,bonuses,arrows,etc. in current game**/
         public List<ScreenItem> ordinance= new	ArrayList<ScreenItem>();
         /**list of bushes, and other non-background in current game**/
	 public List<ScreenItem>	 Obstacles= new	ArrayList<ScreenItem>();

        /**shows this game**/
        public final View view;
        public final static int	NEWGUYSCORE=	10000;
        public final static int	REDBALLFREQ=			8;
        public final static int	NINJA_FREQUENCY	=	8;
        public final static int	NINJA_ATTACK_FREQ	=	30;
        public final static int	NINJA_CHANGEKIND_FREQ=	14;
        //public final static int	NINJACHANGEKINDFREQ	24	Pre-Brian
        public final static int	NINJA_CHANGE_DIR_FREQ=	6;
        //public final static int	NINJACHANGEDIRFREQ	8	Pre-Brian
        public final static int	NOT_JUMP_FREQ=			7;
        public final static int	ASSAISINATE_FREQ=		26;
        //public final static int	ASSAISINATEFREQ		36	Pre Brian
        public final static int	ARCHER_FREQUENCY	=	60;
        public final static int	SWORDSMEN_FREQUENCY=	100;
        public final static int CHANGE_TYPE_FREQ=		15;
        public final static int	ARROW_FREQ=			20;
        public final static int	TRIDENT_FREQ=			28;
        public final static int	NO_BONUS_FREQ	=		30;
        public final static int	MULTIPLIER_FREQ	=	20;
        public final static int	HYPERSPACE_FREQ	=	28;
        public final static int	STAR_FREQ	=		18;
        public final static int	ADVANCE_LEVEL_FREQ=	40;
        public final static int	YINYANG_FREQ=			48;
        public final static int	BLACKHOLE_FREQ	=	21;
        public final static int	BALL_FREQ=			17;
        public final static int	FORCEFIELD_FREQ	=	35;
        public final static int	FREEZE_FREQ=			29;
        
	 /**
	  * One "Loop" of the game.  Refeshes the view and moves each moveable screen object.
          * If(GameOver)
          * If(LevelOver)
          * If(Paused)
          *     CheckDeaths()
          *         
          *     move()
          * If(not Movie)
          *     AddEnemy()
          *     setFutureMovement()/setFuruteAction/Direction()
          * view.refresh()
	  **/
	 public void loop()
	 {
            if(!isGameOver()) {
                //level prelude
                //add 3 enemies
                if(!level.isLevelOver())	{
                    //pause?

                    if(!isPaused()) {
                        //check deaths/interactions, end	game?: update HighScores
                        //check that all enemies for level are dead=end level

                        for(Player player : players)	{
                            player.checkDeaths(enemies,ordinance);

                            if(0 == player.freezer) {
                                player.move();
                            } else {
                                player.freezer--;
                            }

                            if(player.forceField != 0) {
                                player.forceField--;
                            }

                        }

                        for(Enemy enemy : enemies) {
                            enemy.move();
                            if(this.level.mode.equals(Level.MODE.CONTINUE)) {
                                //if NOT a movie
                                enemy.setFutureMovement();
                            }
                        }
                        for(ScreenItem weapon : ordinance) {
                            weapon.move();
                        }
                        
                        if(this.level.mode.equals(Level.MODE.CONTINUE)) {
                            addEnemy();
                            level.cleanEnemies();
                        }

                        //paint background
                        //paint screen	items, players	& scores
                    }
                    view.refresh();

                   

                } else {    //level over
                    pause(true);
                    //if(level > 1)	doSound(LEVELOVERSOUND);		//Plays level done sound if not the first screen
                    this.level.levelPrelude(/*"Level "+ this.level.level_num*/);
                    //this.level.nextLevel();
                    //add three enemies
                    pause(false);
                }
            }
            else {  //game over
                pause(true);    //stop this loop
                
//                this.view.gameBoard.showCenteredText(Util.strRes.getProperty(GAME_OVER,"Game Over"));
                //update Highscores
                //change menu to Pause=greyed
                	/*GameOver Section*/
		/*		
		if(Continue < ENDGAME)
			doGameOver(theEvent, &clock);
		
		NoScreen[NINJA]= NoScreen[ARCHER]= NoScreen[SWORDSMEN]= NoScreen[SKELETON]= NiLevel[NINJA]= NiLevel[ARCHER]= NiLevel[SWORDSMEN]= 0;
		
		HiliteMenu(0);
		
		if(Continue == CONTINUEGAME)
			{
			setFileMenu(0,0,1,1,1,0);
			level--;					//will be incremented by level setup
			resetPlayer(&Frank, RIGHT, RESETCONTINUE);
			if(Matt.mode != NEVERPLAYED)	resetPlayer(&Matt, LEFT, RESETCONTINUE);
			
			goto beginnewlevel;
			}
		
		DisposeWindow(theWindow);		//Clears windows
		SetPort(qd.thePort);
		eraseEnemies(&first);			//only to use MaxMem()
		}
		
	if(Continue == QUITAPP)
		reStartProc(resolution);
	if(Continue == PAUSEGAME)
		{
		Continue == CONTINUE;
		CheckItem(FileMenu, PAUSEITEM, TRUE);
		HiliteMenu(0);
		pause();
		}*/
                view.save.enableInputMethods(false);
            }
	 }
        
	 /** Creates a	new instance of Game	
	  * sets up repetitive "Loop" to redraw every milli-scond.
          * @param view View associated with this game.
	  **/
	 public Game(View view)	{
            this.view= view;
                //---Set up Applicateion---
	 }
         
         public void startGame() {
             //Dialog to let user start game
             NewGame startDlg= new NewGame(this);
         }

         /**
          * creates and starts a new game.  Removes all old games.
          **/
         public void startGame(int level_num) {
             
              //---Start Game---
              //get Preferences
              //guiltScreen();

            //LevelSetup();
            this.level= new Level(this);
            this.level.level_num= level_num;
            //Setup	bkgnd	image	(256 colors)
            //check	if	any player is dead, all	deal=end	of	game
            //set up ho wmany enemy's	& types
                //warlordLevelStart
                //bonusLevelStart
                //play move every 10 levels

                if(null == view) {
                    //throw new Error("View must be instantiated before game can be started.")
                }

                 //Setup All Players
//                  players.add(new Player(this, "Lee", new Point(200, 100), "Red", Color.RED));
                  //enemies.add(new Enemy(this, Enem"Green"));

                //pause menu item is active
                view.addBoard();

                this.level.levelPrelude(/*"Level "+ this.level.level_num*/);

                //hide mouse
                pause(false);   //start looping
              

              //runGame();
        }
	 
         private void writeObject(java.io.ObjectOutputStream out)
             throws IOException {
             //out.writeInt(level);
             for(Player man : players) {
                    out.writeObject(man);
                    //s.writeObject(oOut);
                }

        }
        
         private void readObject(java.io.ObjectInputStream in)
             throws IOException, ClassNotFoundException {
             //level= in.readInt();
             while(in.available() > 0) {
                    Player man= (Player)in.readObject();
                    players.add(man);
                }

        }

        /**
         * does what finalize should do.
         **/
        public void cleanUp() {
            for(Player man : players) {
                if(this.view.application.highScores.isHighScore(this.level.level_num, man.score)) {
                    this.view.application.highScores.addHighScore(man.name,this.level.level_num,man.score);
                }
                man.saveKeys();
            }
        }

        /** 
	 * override from Object.finalize().
	 * saves the highscore.
	 **/ 
        protected void finalize() throws Throwable {
            cleanUp();
            super.finalize();
        }

    /**
     * adds enemies when appropriate.
     **/
    void addEnemy() {
        if(level.getEnemyCount() > 0) {
            final int whichPort= Util.random.nextInt(view.gameBoard.NUMOEP);
            if( view.gameBoard.canEnemyEnter(whichPort) ) {
                if( level.ninja_count > 0 && Util.random.nextInt(NINJA_FREQUENCY) == 0) {
                    this.level.ninja_count--;
                    this.enemies.add(new Enemy(this, this.view.gameBoard.enemy_Port[whichPort].getLocation(), Enemy.POINTS.NINJASCORE, "Green", true));
                } else if(level.archer_count > 0 && Util.random.nextInt(ARCHER_FREQUENCY) == 0) {
                    this.level.archer_count--;
                    this.enemies.add(new Archer(this, this.view.gameBoard.enemy_Port[whichPort].getLocation()));
                    //this.enemies.add(new Enemy(this, this.view.gameBoard.enemy_Port[whichPort].getLocation(), Enemy.POINTS.ARCHERSCORE, "Green"));
                } if(level.swordsmen_count > 0 && Util.random.nextInt(SWORDSMEN_FREQUENCY) == 0) {
                    this.level.swordsmen_count--;
                    this.enemies.add(new Swordsman(this, this.view.gameBoard.enemy_Port[whichPort].getLocation()));
                } 
            }
        }
    }

    /**
     * changes and saves the Action Key Preferences for any player(s).
     **/
    void changeKeys() {
        KeyModify dialog= new KeyModify(this.view.frame, this.players);
        dialog.modifyKeys();
    }
    
    /**
     * @return whether the game is over
     **/
    public boolean isGameOver() {
        for(Player man : this.players) {
            if(man.lives > 0 || !man.isDead()) {
                return false;
            }
        }
        
        return true;    //all players are out of lives
    }
    
    /**
     * @return whether the game is paused.
     **/
    public boolean isPaused() {
        return this.paused;
    }

    /**
     * pauses and un-pauses the game "Loop."
     * @param pause whether to pause, otherwise unpauses the game.
     **/
    void pause(boolean pause) {
        if(pause == this.paused)    return; //already done.)
        
        this.paused= pause;
        this.view.pause.setState(pause);

        if(pause) {
            if(null != cycle)   cycle.cancel();
        } else {
          cycle=	new Timer();
          cycle.schedule(	new TimerTask() {
                public void	run()	{ loop();  }
                },	512,	GAME_SPEED);
          
          //ObscureCursor();
        }
    }
    
    /**
     * ends the current game.
     **/
    void end() {
        /*doSound(ENDGAMESOUND);
	CheckItem(FileMenu, PAUSEITEM, FALSE);
	Continue= ENDGAME;*/
    }
 }

package hero;

import java.util.ArrayList;
import java.io.IOException;
import java.awt.Point;
import java.awt.Image;
import java.applet.Applet;

/**
 * represents the enemy Ninjas
 *	@author	ftaylor
 */
public class Enemy extends	Human	{
    /** only set of icons for Enemy, will not reload icons for each enemy instance @see Enemy.static{}**/
    public static ArrayList<Image> ninja_icons= new ArrayList<Image>(29);
    public static ArrayList<Image> archer_icons= new ArrayList<Image>(29);
    public static ArrayList<Image> swordsmen_icons= new ArrayList<Image>(37);
    
    static {
        try {
            // Human.setIcons(ninja_icons, "Ninja");
            // Human.setIcons(archer_icons, "Ninja");
            // Human.setIcons(swordsmen_icons, "Ninja");
            Swordsman.addSwordIcons(swordsmen_icons);
        } catch(IOException ex) {
            System.out.println(ex);
        }
    }


    
    /**
     * @return is opponent close enough to kill?
     * @param opponent thing to check that is close.
     * @see getKillAction()
     **/
    public ACTION reachable(ScreenItem opponent) {
        return reachable(opponent.place);
    }
    
    public ACTION reachable(Point opponent_place) {
        final int space= Math.abs(opponent_place.x- this.place.x)+ Math.abs(opponent_place.y- this.place.y);
        final int KILL_TOLERANCE= V_KILL_TOLERANCE+ H_KILL_TOLERANCE;
        
        if(space < KILL_TOLERANCE)
            return ACTION.PUNCH;
        if(space < KILL_TOLERANCE* 2)
            return ACTION.FLIP;
        if(space < KILL_TOLERANCE* 3)
            return ACTION.JUMP;
        else
            return ACTION.NONE;
    }

    /** Kind of Enemy--what style he exhibits**/
    public static enum KIND	{ AVOIDH, AVOIDV,	COPYASKEW, COPYASKEWWALK, COPYWALK,
	COPY,	RANDOM, COPYOPPWALK,	COPYOPPOSITE, VERT,
	HORIZ, KILL, ASSASIN, EYESGOOD, EH1,
	EH2, EH3, ATTACK,	OUTC,	OUT,
	IN, INC,	STAB,	STABOUT1, STABOUT2,
	STABOUT3, STABIN3, STABIN2, STABIN1, STABDONE
	}

    /** Type of Enemy--swordsmen vs. archer, etc.**/
    public static enum TYPE	{ NINJA,	ARCHER, SWORDSMEN, SKELETON, ARROW,
	BLUEBALL, REDBALL, BONUSBALL,	POINTS, MULTIPLIER,
	YINYANG,	STAR,	HYPERSPACE,	ADVANCELEVEL, BLACKHOLE,
	FREEZE, FORCEFIELD, RESSURECTION, FIRECRACKER
	}

        /** Aggressivness of Enemy, maybe should be integer **/
        public static enum AGGRESSION_DIRECTION { DIRECT, AVOIDANCE, ASKEW, RANDOM }
        public static enum AGGRESSION_ACTION { WALK, ACTIVE, RANDOM }
        
	 public KIND	NINJAKINDBOUNDS=KIND.KILL;
	 public KIND DEFAULTKIND=	  KIND.AVOIDH;
         public final static int CHANGE_VICTIM_FREQ= 10;
         public final static int CHANGE_TYPE_FREQ= 5;
         public static int ASSASSINATE_FREQ= 5;
         public final static int PRECISION= 16;

//All Speeds must be even for Integer division by 2
        final static int	NHSPEED=    10;
        final static int	NVSPEED=8;
        final static int	NHFSPEED=28;
        final static int	NVFSPEED=24;
        final static int	NHJSPEED=30;
        final static int	NVJSPEED=26;

        final static int	NAPRESSPACE=4;

        //Death Zones CODE= [K=Kill] [TYPE] [DIR] [LTRB=Left,Top,Right,Bottom]
        final static int	NPRADD=		5;
        final static int	NPLADD=		25;
        final static int	NPUADD=		30;
        final static int	NPDADD=		7;

	 TYPE			 type;
	 KIND			 kind;
         AGGRESSION_DIRECTION    hatred;
         AGGRESSION_ACTION       laziness;
         Point                   victim_location;
         final boolean                martial_arts;

	 /** Creates a	new instance of Enemy 
          * @param game Game this Enemy is involved in.
          * @param location initial location on Board.
          * @param points how many points this Enemy is worth killed.
          * @param color @deprecated "type" of enemy for Icon purposes.
          **/
	 public Enemy(Game game, Point location, POINTS points, String color, boolean knows_karate) {
            super(game, location, points);

            this.martial_arts= knows_karate;
            
            this.jumps= 2;
            this.hatred= (AGGRESSION_DIRECTION.values())[Util.random.nextInt(AGGRESSION_DIRECTION.values().length)];
            this.laziness= (AGGRESSION_ACTION.values())[Util.random.nextInt(AGGRESSION_ACTION.values().length)];
            victim_location= new Point(300,300);

                 // try {
                      // setIcons(color);
                      setIcon();
                  // } catch(IOException ex) {
                        // System.out.printf("%s\n", ex);
                    // }
            
	 }

         /**
          * Tells the enemy what to do next.
          **/
         void setFutureMovement() {
            final Point oldPlace= this.place;

            if(Util.random.nextInt(CHANGE_VICTIM_FREQ) == 0) {
                victim_location= game.players.get(Util.random.nextInt(game.players.size())).place;
                this.hatred= (AGGRESSION_DIRECTION.values())[Util.random.nextInt(AGGRESSION_DIRECTION.values().length)];
                this.laziness= (AGGRESSION_ACTION.values())[Util.random.nextInt(AGGRESSION_ACTION.values().length)];
            }
            
            if(Util.random.nextInt(CHANGE_TYPE_FREQ) == 0) {
                //this.kind= KIND.RANDOM;
                ASSASSINATE_FREQ= 1+ Util.random.nextInt(this.game.level.level_num);
            }
            
            if(!martial_arts) return;
            
            //killAction is the most aggressive course of action.
            Human.ACTION killAction= getKillAction();
            
            if(killAction.equals(ACTION.WALK)) {
                setFutureDirection(this.direction);//pushed= true;
            } else if(Util.random.nextInt(ASSASSINATE_FREQ) == 0) {
                setFutureAction(killAction);
            }
            
        if(true)    return;
            
            switch(hatred) {
                case DIRECT:
                    setFutureDirection(Util.direct(this.place, victim_location, PRECISION));
                    break;

                case AVOIDANCE:
                    DIRECTION direct= Util.direct(this.place, victim_location, PRECISION);
                    if( direct.equals(DIRECTION.LEFT))  setFutureDirection(DIRECTION.RIGHT);
                    if( direct.equals(DIRECTION.RIGHT))  setFutureDirection(DIRECTION.LEFT);
                    if( direct.equals(DIRECTION.UP))  setFutureDirection(DIRECTION.DOWN);
                    if( direct.equals(DIRECTION.DOWN))  setFutureDirection(DIRECTION.UP);
                    break;
                    
                case ASKEW:
                    DIRECTION direction= Util.direct(this.place, victim_location, PRECISION);
                    if( direction.equals(DIRECTION.LEFT))  setFutureDirection(DIRECTION.UP);
                    if( direction.equals(DIRECTION.RIGHT))  setFutureDirection(DIRECTION.DOWN);
                    if( direction.equals(DIRECTION.UP))  setFutureDirection(DIRECTION.RIGHT);
                    if( direction.equals(DIRECTION.DOWN))  setFutureDirection(DIRECTION.LEFT);
                    break;
                    
                case RANDOM:
                    setFutureDirection(Util.randomDirection());
                    break;
            }
            
            if(martial_arts) {
                switch(laziness) {
                    case ACTIVE:
                        setFutureAction(killAction);
                        break;
                    case WALK:
                        setFutureAction(ACTION.WALK);
                        pushed= true;
                        break;
                    case RANDOM:
                        setFutureAction((ACTION.values())[Util.random.nextInt(ACTION.values().length)]);
                        break;
                }
            }

            
            /*if(willBeDead()) {
                this.setFutureAction(ACTION.STAND);
            }*/
        }
        
        /**
         * @see super.move()
         **
        public void move() {
            //move, reset movement, if hit wall or barrier
            setDirection(futureDirection);
            setAction(futureAction);
            //reset action requests for next move
            //setFutureDirection(DIRECTION.NONE);
            setFutureAction(ACTION.NONE);

            //If I tacked, then reset what step I'm on
           if(tack) {
                step= 0;
                tack= false;
            } else { 
                step++;
            }

            //show the player's icon based on what step he's on
            setIcon();
 
            //reset all other values
            pushed= false;
        }*/
        
        /**
         * @see super.setIcons()
         * sets the Enemies' icons to the appropriate icons for this enemy type.
         **/
        void setIcons(String type, Applet webApp) throws IOException {
            this.icons= Enemy.ninja_icons;
        }

/*
void attack(enemyPtr Enemy, playerPtr Sprite)
{
(forgetPoint.h)= getDist(Sprite->place, Enemy->place, Enemy->dir);

if((Enemy->dir)%2)	//UP or DOWN
	{
	if((forgetPoint.h) < (NVFSPEED))
		punch(Enemy);
	else if((forgetPoint.h) < (NVJSPEED* 2) || random(NOTJUMPFREQ))
		flip(Enemy);
	else
		jump(Enemy);
	}
else
	{
	if((forgetPoint.h) < (NHFSPEED))
		punch(Enemy);
	else if((forgetPoint.h) < (NHJSPEED* 2))
		flip(Enemy);
	else
		jump(Enemy);
	}
changeKind(Enemy, FALSE);
}

void setAttack(enemyPtr Enemy, playerPtr Sprite)
{
SetPt(&forgetPoint, (Sprite->place).left +(HPLAYER/2),  (Sprite->place).top +(VPLAYER/2));//Will Replace with .topLeft when I find out how*
place.setLocation(x,y);
	
PtToAngle(&(Enemy->place), forgetPoint, &(forgetPoint.v));
(forgetPoint.v)= ((forgetPoint.v) < 45) ? (forgetPoint.v)+ 315 : (forgetPoint.v)-45;

if((forgetPoint.v) < 90)		(Enemy->dir)= RIGHT;
else if((forgetPoint.v) < 180)	(Enemy->dir)= DOWN;
else if((forgetPoint.v) < 270)	(Enemy->dir)= LEFT;
else							(Enemy->dir)= UP;

(Enemy->mode)= STAND;
(Enemy->kind)++;
if(Enemy->type == NINJA || Enemy->type == SKELETON)
	{
	(Enemy->iconNum)= (Enemy->dir)+ SNUM;
	if(!random(ASSAISINATEFREQ))	(Enemy->kind)= ATTACK;
	else if(!random(level))	(Enemy->kind)++;
	}
else
	(Enemy->iconNum)= (Enemy->dir)+ SNUM2;
}
*/
    /**
     * returns the next logical thing for the Enemy to do next based on his personality.
     * @return what action the enemy should do next.
     **/
    public ACTION getKillAction() {
        if(Util.random.nextInt(ASSASSINATE_FREQ) == 0) {
        
            return reachable(victim_location);
        }
        
        if(Util.random.nextInt(2) == 0) {
            return ACTION.STAND;
        } else {
            return ACTION.WALK;
        }
    }
}

package hero;

import java.awt.Point;
import java.awt.Dimension;
import java.awt.Image;
import java.util.List;
import java.util.ArrayList;
import java.io.IOException;
import java.awt.Graphics2D;
import java.applet.Applet;

/**
 * represents all screen items.
 *	@author	ftaylor
 */
public abstract class ScreenItem implements Comparable<ScreenItem>	{
        /**Game this piece is involved in**/ 
        public final Game game;
        /**how far into each action is the piece, for multi-part moves**/
        public int step= 0;

        /** Points given to Player, when Enemy killed**/
	 public enum POINTS { ZEROSCORE(0),	IMMORTAL(1), NINJASCORE(150),	ARCHERSCORE(250),
	SWORDSMENSCORE(350),	ARROWSCORE(100), TRIDENTSCORE(500),	SHAFTSCORE(500),
	SKELETONSCORE(400), BLUEBALLSCORE(150), REDBALLSCORE(250), BONUSBALLSCORE(100),
	STARSCORE(300), SAMURAISCORE(2000),	PRINCESSSCORE(5000);
		  
		  public	int score;
		  POINTS(int score)
		  {
				this.score=	score;
		  }

	 }	 
         /** points awarded to player when item is killed**/
         final POINTS		 points;
         /**all available directions to go**/
	 public static enum DIRECTION { LEFT, RIGHT, UP, DOWN, NONE }
         /** Direction piece is facing or moving**/
         protected DIRECTION	 direction; //direction the screen item is facing

         ArrayList<Image> icons= new ArrayList<Image>();    //contains all icons available for this piece.  //Map<String,Image> icons= new HashMap<String,Image>(24);
         transient int   iconNum;   //should be moved to hero.Human.setIcon only
         transient Image icon;	 //icon currently showing
	 
         transient Point	  place;    //where on the board this piece is, not where to draw icon
         final Dimension size;  //height and width of drawn object, assumed to be standing at this.place
         final Point ICON_LOCATION; //how far from this.place is the upper,left corner of it's icon graphic.
	 
         final Dimension speed; //how fast something normally moves.
         boolean	alive= true;    //if the piece is active/alive
         boolean        movable= true;  //if piece moves, or is it just for display purposes
	 
	 /** Creates a	new instance of ScreenItem.
          * setIcons() and setIcon() should be called by each individual constuctor.
          * @param game the game this item is associated with.
          * @param location location of item.
          * @param size height and width of item
          * @param icon_loaction, how far is the upper,left corner from location in graphic.
          **/
	 public ScreenItem(Game game, Point location, Dimension size, Point icon_location, Dimension speed, POINTS points)	{
		  this.game= game;
                  this.place=	location ;
                  this.size= size;
                  this.ICON_LOCATION= icon_location;
                  this.speed= speed;
                  this.points= points;

                  this.direction= DIRECTION.RIGHT;
	 }
         
         public boolean checkWall(final Point place) {
             return this.game.view.gameBoard.barriers.contains(place);
         }
	 
         /**
           * checks whether this item has hit a wall.
           * @return if this item is currently "in" a wall.
           **/
       public boolean checkWall() {
            return checkWall(this.place);
        }

          /**
           * checks whether this item has fallen into water.
           * @return if this item is currently in water.
           **/
      public boolean checkWater() {
           return this.game.view.gameBoard.water.contains(this.place);
        }

        /**
         * wheter a Sprite can die now because he's not in the air.
         * @return whether a can die now.
         **/
        abstract boolean canDie();
        
       /**
         * wheter a piece can kill.
         * @return whether a kill can die.
         **/
        abstract boolean canKill();

      /** 
       * sets up all the icons that this item could use, depending on type.
       * @param type which type of icon to load.
       **/ 
      abstract void setIcons(String type, Applet webApp) throws IOException;

      /**
       * moves the object one step.
       * setAction()
       * if(no action)
       *    nextStep()
       * checkWall()
       * reset values
       * setIcon()
       * step++
       **/
      public void move() {
        if(movable) {
            switch(direction) {
                case LEFT:
                    place.translate(-speed.width, 0);
                    break;
                case RIGHT:
                    place.translate(speed.width, 0);
                    break;
                case UP:
                    place.translate(0, -speed.height- 2);
                    break;
                case DOWN:
                    place.translate(0, speed.height- 2);
                    break;
            }
        }
         
        if(checkWall()) {
            this.die();
        }
        
        setIcon();
        step++;
      }
      
      /**
       * does the final kill and remove of an item.
       **/
      public void kill() {
        alive= false;
      }
      
      /**
     * makes the object die.
     **/
    public void die() {
        //playSound(death_knell);
    }
    
    /**
      * @return whether this item kills another item now.
      * @param opponent opponent to test that this item kills.
      **/
    public abstract boolean kills(ScreenItem opponent);
      
      public int compareTo(ScreenItem item) {
          return this.place.y- item.place.y;
      }
      
      /** @return the icon currently being used for this player **/
      public Image getIcon() { return icon; }
      
      /**
       * Sets which Icon to use for this player.
       * changes the action, if the next step has to be taken.
       **/
      public abstract void setIcon();
         
      /**
       * draws the piece on the screen
       * @param screen which screen to draw this peice apon.
       **/
      public void draw(Graphics2D screen) {
        screen.drawImage(this.getIcon(), this.place.x- this.ICON_LOCATION.x, this.place.y- this.ICON_LOCATION.y, null);
      }
      
      public void setDirection(DIRECTION direction) {
          this.direction= direction;
      }
      public DIRECTION getDirection() { return this.direction; }

      /**sound played when item dies**/
      //public Sound death_knell; //sound to play at death
      
      //temp: list of Mac sounds used
      public static enum SOUNDS {
        QUITGAMESOUND,	//- application sounds, 8192
	LEVELOVERSOUND,
	ENDGAMESOUND,
	GAMEOVERSOUND,		//8195
	PAUSESOUND,
	UNPAUSESOUND,
	PREFERENCESSOUND,
	HIGHSCORESSOUND,
	DROWNEDSOUND,	//8200- Player killed
	KILLEDSOUND,
	PUNCHSOUND,		//8202- Player moves
	FLIPSOUND,
	JUMPSOUND,
	PASSAGESOUND,	//8205- Player hits wall
	HITSIDESOUND,
	HITSOUND,		//8207- Enemy dies
	BREAKARROWSOUND,
	BREAKTRIDENTSOUND,	//8209
	BREAKSTARSOUND,
	FREEZESOUND,	//8211- Bonus action
	FORCEFIELDSOUND,
	SHAKESOUND,
	NEWGUYSOUND,	//8214- Extra Guy
	NEWHSSOUND,
	BALLAPPEARINGSOUND,	//8216- Bonus Appearance
	MULTIPLIERAPPEARINGSOUND,
	HYPERSPACEAPPEARINGSOUND,	//8218
	ARROWSOUND,
	RESSURECTIONSOUND,
	YINYANGSOUND,			//8221
	STARSOUND,
	ADVANCELEVELSOUND,
	BLACKHOLESOUND,			//8224
	FIRECRACKERSOUND,
	BLUEPBSOUND,		//8226- Bonus Taken
	REDPBSOUND,
	BONUSBSOUND,
	MULTIPLIERSOUND,	//8229
	HYPERSPACESOUND,
	EXPLOSIONSOUND,		//8231- Bonus Dissapears
	BACKGROUNDMUSIC,	//8232- Background Music
	CLEARSCORESOUND }
}

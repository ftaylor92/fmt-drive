package hero;

import java.awt.Point;
import java.awt.Graphics2D;

/**
 * Represents Archer Enemy person.
 * @author  TaylorFM
 **/
public class Archer extends Enemy {
    int arrows= 4;
    /** Creates a new instance of Archer 
	**/
    public Archer(Game game, Point location) {
        super(game, location, POINTS.ARCHERSCORE, "Archer", false);
    }
    
    public void draw(Graphics2D screen) {
        super.draw(screen);
        
        screen.drawString(this.action.name(), place.x, place.y);
    }
    
    public void move() {
        super.move();
        
        if(arrows > 0 && step > 8 )
        switch(this.direction) {
            case LEFT:
                if(Math.abs(this.place.y-victim_location.y)<15 &&
                    this.place.x > victim_location.x ) {
                        shoot();
                }
                break;
            case RIGHT:
                if(Math.abs(this.place.y-victim_location.y)<15 &&
                    this.place.x < victim_location.x ) {
                        shoot();
                }
                break;
            case UP:
                if(Math.abs(this.place.x-victim_location.x)<15 &&
                    this.place.y > victim_location.y ) {
                        shoot();
                }
                break;
            case DOWN:
                if(Math.abs(this.place.x-victim_location.x)<15 &&
                    this.place.y < victim_location.y ) {
                        shoot();
                }
                break;
                
                    
        }
        
    }
    
    public void shoot() {
        step= 0;
        arrows--;
        Star star= new Star(this.game);
        star.place= (Point)this.place.clone();
        star.direction= this.direction;
        
        this.game.ordinance.add(star);
    }
}

package hero;

import javax.swing.JComponent;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Composite;
import java.awt.AlphaComposite;
import java.awt.image.VolatileImage;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.awt.Image;
import java.awt.geom.Area;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.Rectangle;
import java.awt.Point;
import java.awt.Font;
import java.awt.FontMetrics;

import hero.Enemy.TYPE;

/**
 * represents the game board and it's items.
 *	@author	ftaylor
 */
public class Board extends	JComponent {
        /** shows Board Model**/
	public final View	view;
        /**Spacing for Scoreboard**/
        public final static int LINE_SPACE= 15;
	public final static int	TILE_WIDTH=	32;
	public final static int	TILE_HEIGHT= 32;
        public final static int       TILE_COUNT= 5;
        
        /**background picture where all is drawn before smoothly applied tot he screen**/
        VolatileImage backgroundImage;
        final Image	bush=	new ImageIcon("images/board/bush.gif").getImage();
        final Image	rock=	new ImageIcon("images/board/rock.gif").getImage();
        public final static int NUMOEP= 3;
        Rectangle[] player_Port={new Rectangle(), new Rectangle()};
        Rectangle[] enemy_Port={new Rectangle(), new Rectangle(), new Rectangle()};
        Point levelPlace;
        final static int SCORE_BOARD_HEIGHT= 70;

        /**water and barrier regions**/
        public Area   barriers= new Area();
        public Area   water= new Area();
	
	 /** Creates a	new instance of Board 
           * @param view View associated with this Board
          **/
	 public Board(View view) {
		  super();
		  
		  this.view= view;
                  
//                  this.setFont(Font.getFont("Arial Black Bold 10 Point"));
	 }

        /**
         * creates the background image to be used in each level.
         * Sets up tiles, Water, bushes, # of enemies, plays new Level sound.  
         * Checks if players are dead forever.
         **/
         public void createBackground()
        {
            //if is a Movie, then set up differntly.
            //make this and paint() use 256 colors
            backgroundImage=	this.createVolatileImage(this.getWidth(), this.getHeight());
            Graphics2D backgroundScreen= backgroundImage.createGraphics();
            final int levelSetNum= view.application.game.level.level_num% TILE_COUNT;
            final int width= backgroundImage.getWidth()- (this.getInsets().left+ this.getInsets().right)- 8;
            final int height= backgroundImage.getHeight()- (this.getInsets().top+ this.getInsets().bottom)- 57-SCORE_BOARD_HEIGHT;
            final Color old_color= backgroundScreen.getColor();
            final FontMetrics fm= backgroundScreen.getFontMetrics(backgroundScreen.getFont());
            
            //Draw Background first, then loose memory for pieces.
            Map<String,Image> images= new HashMap<String, Image>(21);
            //tiles
            images.put("tile", new ImageIcon("images/board/tile"+ levelSetNum +".gif").getImage());

            //waters
            images.put("water_right", new ImageIcon("images/board/LEFT_WATER.gif").getImage());
            images.put("water_left", new ImageIcon("images/board/LEFT_WATER.gif").getImage());
            images.put("water_up", new ImageIcon("images/board/LEFT_WATER.gif").getImage());
            images.put("water_down", new ImageIcon("images/board/LEFT_WATER.gif").getImage());
            images.put("water_right_up", new ImageIcon("images/board/LEFT_WATER.gif").getImage());
            images.put("water_right_down", new ImageIcon("images/board/LEFT_WATER.gif").getImage());
            images.put("water_left_up", new ImageIcon("images/board/LEFT_WATER.gif").getImage());
            images.put("water_left_down", new ImageIcon("images/board/LEFT_WATER.gif").getImage());
            images.put("water_center", new ImageIcon("images/board/LEFT_WATER.gif").getImage());
            images.put("lillypad_0", new ImageIcon("images/board/Lillypad0.gif").getImage());
            images.put("lillypad_1", new ImageIcon("images/board/Lillypad1.gif").getImage());
            images.put("lillypad_2", new ImageIcon("images/board/Lillypad2.gif").getImage());
            images.put("lillypad_3", new ImageIcon("images/board/Lillypad3.gif").getImage());

            //walls
            images.put("wall_right", new ImageIcon("images/board/RIGHT_WALL"+levelSetNum+".gif").getImage());
            images.put("wall_left", new ImageIcon("images/board/LEFT_WALL"+levelSetNum+".gif").getImage());
            images.put("wall_up", new ImageIcon("images/board/UP_WALL"+levelSetNum+".gif").getImage());
            images.put("wall_down", new ImageIcon("images/board/DOWN_WALL"+levelSetNum+".gif").getImage());
            images.put("wall_right_up", new ImageIcon("images/board/RIGHT_UP_WALL"+levelSetNum+".gif").getImage());
            images.put("wall_right_down", new ImageIcon("images/board/RIGHT_DOWN_WALL"+levelSetNum+".gif").getImage());
            images.put("wall_left_up", new ImageIcon("images/board/LEFT_UP_WALL"+levelSetNum+".gif").getImage());
            images.put("wall_left_down", new ImageIcon("images/board/LEFT_DOWN_WALL"+levelSetNum+".gif").getImage());
            
            //passages
            images.put("entrance_right", new ImageIcon("images/board/RIGHT_ENTRANCE.gif").getImage());
            images.put("entrance_left", new ImageIcon("images/board/LEFT_ENTRANCE.gif").getImage());
            images.put("entrance_up", new ImageIcon("images/board/UP_ENTRANCE.gif").getImage());
            images.put("entrance_down", new ImageIcon("images/board/DOWN_ENTRANCE.gif").getImage());
            images.put("passage_right", new ImageIcon("images/board/RIGHT_PASSAGE.gif").getImage());
            images.put("passage_left", new ImageIcon("images/board/LEFT_PASSAGE.gif").getImage());
            images.put("passage_up", new ImageIcon("images/board/UP_PASSAGE.gif").getImage());
            images.put("passage_down", new ImageIcon("images/board/DOWN_PASSAGE.gif").getImage());
            images.put("doors", new ImageIcon("images/board/CLOSED_DOOR.gif").getImage());

            //lay tiles
            for(int x= 0; x <	width; x+=	TILE_WIDTH)	{
                for(int y= 0; y <	height;	y+= TILE_WIDTH) {
                    backgroundScreen.drawImage(images.get("tile"), x, y+SCORE_BOARD_HEIGHT, null);
                    //backgroundScreen.drawImage(bush, x, y, null);
                }
            }

            //stand up walls
            int wall_depth= images.get("wall_left").getWidth(this);
            int wall_length= images.get("wall_up").getWidth(this);
            int wall_top_height= images.get("wall_up").getHeight(this);
            int wall_bottom_height= images.get("wall_down").getHeight(this);
            for(int x= 0; x <	width; x+=	TILE_WIDTH) {
                backgroundScreen.drawImage(images.get("wall_up"), x+ wall_depth, 0+SCORE_BOARD_HEIGHT, null);
                backgroundScreen.drawImage(images.get("wall_down"), x+ wall_depth, height- wall_bottom_height+SCORE_BOARD_HEIGHT, null);
                barriers.add(new Area(new Rectangle(x+ wall_depth,0+SCORE_BOARD_HEIGHT-Human.V_JUMP_DISTANCE, wall_length, wall_bottom_height+Human.V_JUMP_DISTANCE)));
                barriers.add(new Area(new Rectangle(x+ wall_depth,height- wall_bottom_height+SCORE_BOARD_HEIGHT, wall_length, wall_bottom_height+Human.V_JUMP_DISTANCE)));
            }
            for(int y= 0; y <	height;	y+= TILE_WIDTH) {
                backgroundScreen.drawImage(images.get("wall_left"), 0, y+ wall_top_height+SCORE_BOARD_HEIGHT, null);
                backgroundScreen.drawImage(images.get("wall_right"), width- wall_depth, y+ wall_top_height+SCORE_BOARD_HEIGHT, null);
                barriers.add(new Area(new Rectangle(0-Human.H_JUMP_DISTANCE,y+ wall_top_height+SCORE_BOARD_HEIGHT, wall_depth+Human.H_JUMP_DISTANCE, wall_length)));
                barriers.add(new Area(new Rectangle(width- wall_depth, y+ wall_top_height+SCORE_BOARD_HEIGHT, wall_depth+Human.H_JUMP_DISTANCE, wall_length)));
                //backgroundScreen.drawImage(bush, x, y, null);
            }

            //draw corner walls and doors
            backgroundScreen.drawImage(images.get("wall_left_up"), 0, 0+SCORE_BOARD_HEIGHT, null);
            backgroundScreen.drawImage(images.get("wall_right_up"), width-wall_depth, 0+SCORE_BOARD_HEIGHT, null);
            backgroundScreen.drawImage(images.get("wall_left_down"), 0, height- wall_bottom_height+SCORE_BOARD_HEIGHT, null);
            backgroundScreen.drawImage(images.get("wall_right_down"), width-wall_depth, height- wall_bottom_height+SCORE_BOARD_HEIGHT, null);

            backgroundScreen.drawImage(images.get("doors"), (width- images.get("doors").getWidth(this))/2, 0+SCORE_BOARD_HEIGHT, null);

            //draw passages and entrances
            if(0 == Util.random.nextInt(2)) {
                int y= Util.random.nextInt(height- images.get("passage_left").getHeight(this))+SCORE_BOARD_HEIGHT;  //+ images.get("passage_left").getHeight(this);
                backgroundScreen.drawImage(images.get("passage_left"), 0, y, null);
                player_Port[0]= new Rectangle(0,y,images.get("passage_left").getWidth(this),images.get("passage_left").getHeight(this));
                y= Util.random.nextInt(height- images.get("passage_left").getHeight(this))+SCORE_BOARD_HEIGHT;
                backgroundScreen.drawImage(images.get("passage_right"), width- images.get("passage_right").getWidth(this), y, null);
                player_Port[1]= new Rectangle(width- images.get("passage_right").getWidth(this),y,images.get("passage_left").getWidth(this),images.get("passage_left").getHeight(this));
            } else {
                int x= Util.random.nextInt(width- images.get("passage_down").getWidth(this));  //+ images.get("passage_left").getHeight(this);
                backgroundScreen.drawImage(images.get("passage_up"), x, 0+SCORE_BOARD_HEIGHT, null);
                player_Port[0]= new Rectangle(x,0,images.get("passage_down").getWidth(this),images.get("passage_down").getHeight(this));
                x= Util.random.nextInt(width- images.get("passage_down").getWidth(this));  //+ images.get("passage_left").getHeight(this);
                backgroundScreen.drawImage(images.get("passage_up"), x, height- images.get("passage_down").getHeight(this)+SCORE_BOARD_HEIGHT, null);
                player_Port[1]= new Rectangle(x,height-images.get("passage_down").getHeight(this),images.get("passage_down").getWidth(this),images.get("passage_down").getHeight(this));
           }

           enemy_Port[0]= new Rectangle(100,100,50,50);
           enemy_Port[1]= new Rectangle(200,200,50,50);
           enemy_Port[2]= new Rectangle(300,300,50,50);


           int x= (width- fm.stringWidth("Level:"))/2;
           levelPlace= new Point(x+ fm.stringWidth("Level:")+ 4, 20);
           backgroundScreen.drawString("Level: ", x, 20);

           //Player-specific things
           final int SCORE_SPACE= 70;
           Point scorePoint;
           int player_num= 0;
           for(Player man : this.view.application.game.players) {
               //Scoreboard
               backgroundScreen.setColor(man.color);
               if(Util.isEven(player_num)) {
                   scorePoint= new Point(20+ SCORE_SPACE*player_num/2, 20);
               } else {
                   scorePoint= new Point(width- SCORE_SPACE*Math.round(player_num/2)- 20, 20);
               }
               
               int str_width= fm.stringWidth(((man.name.length() > 4) ? man.name :"Power")+":");
               man.scorePoint= new Point(scorePoint.x+ str_width+ 4, scorePoint.y);
               backgroundScreen.drawString(man.name+":", scorePoint.x+(str_width- fm.stringWidth(man.name+":")), scorePoint.y);
               scorePoint.translate(0, LINE_SPACE);
               backgroundScreen.drawString("Lives:", scorePoint.x+(str_width- fm.stringWidth("Lives:")), scorePoint.y);
               scorePoint.translate(0, LINE_SPACE);
               backgroundScreen.drawString("Power:", scorePoint.x+(str_width- fm.stringWidth("Power:")), scorePoint.y);
               scorePoint.translate(0, LINE_SPACE);
               backgroundScreen.drawString("Jumps:", scorePoint.x+(str_width- fm.stringWidth("Jumps:")), scorePoint.y);
               player_num++;
            }

            backgroundScreen.setColor(old_color);
         }

         /**
          * @return if it's safe for enemy to enter.
          * @param whichPort which enemy port to enter.
          **/
	 boolean canEnemyEnter(int which) {
            final int SAFE_HALO= 20;
            final Rectangle ePort= (Rectangle)enemy_Port[which].clone();

            ePort.grow(SAFE_HALO,SAFE_HALO);

            for(Player man : this.view.application.game.players) {
                if(ePort.contains(man.place))   return false;
            }

            return true;
         }

	 /**
	  * overrides super.paint().  Draws all the Screen Objects on top of
	  * the background each second or loop.
	  * @param g @see: super.paint().
	  **/	  
	 public void paint(final Graphics g)
	 {
		super.paint(g);
		
		//Graphics2D g2D= (Graphics2D)g;
                final VolatileImage offScreenImage=	this.createVolatileImage(this.getWidth(), this.getHeight());
                final Graphics2D offScreen= offScreenImage.createGraphics();

		//Draw everything Here


                //Draw Background first
                offScreen.drawImage(backgroundImage, 0, 0, null);

                if(this.view.application.game.level.movie(offScreen)) { //draw movie, and exclude clutter if necc.
                    //Draw Scoreboard, ScreenItems
                    drawScoreBoard(offScreen);
                    drawPieces(offScreen);
                }
                
                //transfers image to screen (w/out flicker)
		g.drawImage(offScreenImage,	0,	0,	null);
	  }
         
         /**
          * Draws all the game's pieces, not background items, shadows or scores, in order so that the perspective (i.e. things that are closer obscure things that are farther away) is maintained.
          * @param screen the screen to which the pieces should be drawn.
          **/
         public void drawPieces(final Graphics2D screen) {
            List<ScreenItem> allPieces= new ArrayList<ScreenItem>();
            
            allPieces.addAll(view.application.game.enemies);
            allPieces.addAll(view.application.game.ordinance);
            allPieces.addAll(view.application.game.players);
            allPieces.addAll(view.application.game.Obstacles);
            Collections.sort(allPieces);
            
            //draw screen objects
            //draw enemies
            for(ScreenItem piece : allPieces) {
                if(piece.alive) {
                    //screen.drawImage(enemy.getIcon(), enemy.place.x- enemy.ICON_LOCATION.x, enemy.place.y- enemy.ICON_LOCATION.y, null);
                    piece.draw(screen);
                    //if(enemy.type.equals(TYPE.SWORDSMEN) && enemy.kind > STAB)	showTrident(first);
                }
            }
            
            //screen.drawImage(man.getIcon(), man.place.x- IconNum.ICON_WIDTH_DIV2, man.place.y- IconNum.ICON_HEIGHT, null); //offScreen.drawString(man.futureAction.name()+":"+man.iconNum+":"+man.step+":"+man.action.name(), man.place.x, man.place.y);


            //debug
            //screen.fill(barriers);
         }
         
         /**
          * Draws the scoreboard, forcefield and Players' shadow on the screen.
          * @param screen on what to draw.
          **/
         public void drawScoreBoard(final Graphics2D screen) {
             	screen.drawString(Integer.toString(this.view.application.game.level.level_num), levelPlace.x, levelPlace.y);
		
                //offScreen.drawString(Double.toString(Util.angle(new Point(40,40), new Point(20,20))), 50, 30);

                //draw Players
					 	//draw forcefield as RoundRect shape
					//check for water deaths
					//moves each enemy, unless frozen
					//draws each enemy by type.
					//check deaths
					//adds new enemies
                for(Player man : view.application.game.players) {
                    //Points/Text
                    screen.drawString(Integer.toString(man.score), man.scorePoint.x, man.scorePoint.y);
                    screen.drawString(Integer.toString(man.lives), man.scorePoint.x, man.scorePoint.y+ LINE_SPACE);
                    screen.drawString(Integer.toString(man.power), man.scorePoint.x, man.scorePoint.y+ LINE_SPACE*2);
                    //screen.drawString(Integer.toString(man.jumps), man.scorePoint.x, man.scorePoint.y+ LINE_SPACE*3);
                    screen.drawString(man.place.x+","+man.place.y, man.scorePoint.x, man.scorePoint.y+ LINE_SPACE*3);

                    if(man.alive) {
                        
                        //draw transparent Shadow---
                        final Composite opacity= screen.getComposite();
                        screen.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.4f));
                        screen.setColor(Color.BLACK);
                        //make larger and move, if in air
                        if(man.canDie()) {  //if in the air, move&enlarge shadow
                            screen.fillOval(man.place.x- 10, man.place.y- 15, 16, 5);
                        } else {
                            screen.fillOval(man.place.x- 6, man.place.y- 19, 19, 7);
                        }
                        screen.setComposite(opacity);
                        
                        //draw Force Field
                        if(man.forceField != 0) {
                            screen.draw3DRect(man.place.x- (man.size.width/2), man.place.y-man.size.height- 30, man.size.width, man.size.height+ 30, true); 
                        }
                    }

                }
         }

	/**
	 * Sets up each level appropriately.
	 * Sets up tiles, Water, bushes, # of enemies, plays new Level sound.  Checks if players are dead forever.
	 **/
	public void	LevelSetUp()
	{
		//if(level)	doSound(LEVELOVERSOUND);		/*Plays level done sound if not the	first	screen*

		//NoScreen[SWORDSMEN]= NoScreen[SKELETON]= NoScreen[ARROW]=	NoScreen[ARCHER]=	NoScreen[NINJA]= 0;	/*Number	of	Enemies currently	on	Screen*
		//if(NiLevel[NINJA] == 0)
		//	NiLevel[NINJA]= (level *3)+ 4;					/*Number	of	Enemies per	level;*
		//if(NiLevel[ARCHER]	==	0)
			//NiLevel[ARCHER]= (level < 4) ?	0 : (level-	3);	/*Number	of	Archers in level*
		//if(NiLevel[SWORDSMEN]	==	0)
			//NiLevel[SWORDSMEN]= (level < 5) ?	0 : (level-	4);	/*Number	of	Swordsmen in level*

//		if((Frank.mode) <	OUTFOREVER)	resetPlayer(&Frank, RIGHT,	RESETSETUP);
//		if((Matt.mode)	< OUTFOREVER)	resetPlayer(&Matt, LEFT, RESETSETUP);

//		fade_to_black(8, true);			//fade if not virgin	level	or	not after movie

		//level++;						/*Increments level*/

//		doBorders(GAME);			/*--Plots Borders	and begins OffScreen	Drawing---*/

//		forgetRect2= makeBoardRect(GameRect);
//		background(forgetRect2);			/*Creates background	graphics	for current	level*/

//		water(GAME);					/*Sets Up Water and Barriers*/
	}
        
        /**
         * Shows text large and cetered on the game board.
         * @param screen on what to draw.
         * @param message test to show.
         **/
        public void showCenteredText(final Graphics2D screen, String message) {
            //Game Over string from properties file.
            final FontMetrics fm= screen.getFontMetrics(screen.getFont());

            final Point place= Util.getCenteredLocation(this.view.content.getBounds(), new Rectangle(0,0,fm.stringWidth(message),24));
            //use 24 point font.
            screen.drawString(message, place.x, place.y);
            
            //draw for a while, then stop flashing
            
            //doSound(GAMEOVERSOUND);
            //gameOverDialog();
        }
}

package hero;

import javax.swing.JApplet;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import javax.swing.SwingUtilities;

import java.awt.Container;
import java.awt.GridLayout;

import java.io.File;
import java.io.Serializable;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import hero.persistent.HighScores;

/**
 * Represents Video Game Hardware console and application framework.
 * @author  TaylorFM
 */
public class ChineseHero extends JApplet {
        final private int version= 1;   //for Serialization
	public Game game= null;
        public View view;
        public HighScores highScores;

    /** 
     * Creates a new instance of Chinese Hero video game.
     **/
    public ChineseHero() {
        getRootPane().putClientProperty("defeatSystemEventQueueCheck", Boolean.TRUE);
        //this.view=	new View(this);
    }

    /**
     * creates a window and view and high-score dialog for this application.
     **/
    public void createWindow() {
        this.view= new View(this);
        highScores= new HighScores(view.frame);
        highScores.getHighscores();
    }

         /**
          * Start of non-web Application.
          * @param args the command line arguments (none), must be null for web start.
          
         public static	void main(String[] args) {
            ChineseHero application= new ChineseHero();
            application.createWindow();
         }
         **/

         public void start() {
            try {
                SwingUtilities.invokeAndWait(new Runnable() {
                    public void run() {
                        if(null != ChineseHero.this.game) {
                            createWindow();
                            //ChineseHero.this.game.pause(false);
                        }
                    }
                });
            } catch (Exception e) {
                System.err.println("Start Failed");
            }
         }
             
         public void stop() {
            try {
                SwingUtilities.invokeAndWait(new Runnable() {
                    public void run() {
                        if(null != ChineseHero.this.game) {
                            ChineseHero.this.game.pause(true);
                        }
                    }
                });
            } catch (Exception e) {
                System.err.println("Stop Failed");
            }             
         }
             
         public void destroy() {
             quit();
         }
         
         public void init() {
             
            Container contentPane = getContentPane();

            contentPane.setLayout(new GridLayout());
            
            try {
                SwingUtilities.invokeAndWait(new Runnable() {
                    public void run() {
                        //createWindow();
                    }
                });
            } catch (Exception e) {
                System.err.println("Could Not Successfully Create Game");
            }
           
         }

        /**
         *  starts a new game.  Ends any old games.
         **/
        public void newGame() {
            //JDialog newGameDlg= new JDialog();
            if(null != game) {
                game.cleanUp();
                game= null;
            }
            game= new Game(this.view);
            game.startGame();
        }

        /**
         * saves the current game as it is now.
         **/
        public void saveGame() {

            JFileChooser chooser = new JFileChooser();
            // Note: source for ExampleFileFilter can be found in FileChooserDemo,
            // under the demo/jfc directory in the JDK.
            
            chooser.setFileFilter(new FileFilter() {
                public boolean accept(File f) {
                    return f.getName().endsWith(".game");
                }
                public String getDescription() {
                    return "Chinese Hero game";
                }
            });
            int returnVal = chooser.showSaveDialog(view.content);
            if(returnVal == JFileChooser.APPROVE_OPTION) {
               System.out.println("You chose to open this file: " +
                    chooser.getSelectedFile().getName());

           FileOutputStream fOut= null;

            try {
                fOut= new FileOutputStream(chooser.getSelectedFile(), false);
                /*
                writeNumToFile(GameFile, theLevel);
                writeNumToFile(GameFile, levelType);
                writeNumToFile(GameFile, theNEIL);
                writeNumToFile(GameFile, theNAIL);
                writeNumToFile(GameFile, theNSIL);
                writeNumToFile(GameFile, Fmode);
                writeNumToFile(GameFile, Fjumps);
                writeNumToFile(GameFile, Fmult);
                writeNumToFile(GameFile, Fletter);
                writeNumToFile(GameFile, Flives);
                writeNumToFile(GameFile, Fscore);
                writeStrToFile(GameFile, Frank.name);
                writeNumToFile(GameFile, Mmode);
                */
             } catch (FileNotFoundException ex) {
                System.out.println(ex);
            }

            try {

               ObjectOutputStream oOut= new ObjectOutputStream(fOut);

                oOut.writeObject(game);

                oOut.close();
            } catch(IOException ex) {
                System.out.println(ex);
            }
    }

            //JDialog newGameDlg= new JDialog();

            game= new Game(this.view);
            game.startGame();
        }

        /**
         * Allows user to choose and then open previously saved game.  Will start the game from where the user left off.
         **/
        public void openGame() {
             JFileChooser chooser = new JFileChooser();
            // Note: source for ExampleFileFilter can be found in FileChooserDemo,
            // under the demo/jfc directory in the JDK.
            
            chooser.setFileFilter(new FileFilter() {
                public boolean accept(File f) {
                    return f.getName().endsWith(".game");
                }
                public String getDescription() {
                    return "Chinese Hero game";
                }
            });
            int returnVal = chooser.showOpenDialog(view.content);
            if(returnVal == JFileChooser.APPROVE_OPTION) {
               System.out.println("You chose to open this file: " +
                    chooser.getSelectedFile().getName());
          }
         FileInputStream fIn= null;
         ObjectInputStream oIn= null;
            try {
                fIn= new FileInputStream(chooser.getSelectedFile());
                oIn= new ObjectInputStream(fIn);
                /*
                 getNumFromFile(GameFile, level, unsigned short);
                getNumFromFile(GameFile, levelType, long);

                if(levelType == STARTATWARLORD)
                        Continue= STARTWARLORD;
                else if(levelType == STARTATBONUS)
                        Continue= STARTBONUS;
                else
                        Continue= STARTNORMALLY;

                getNumFromFile(GameFile, NiLevel[NINJA], unsigned short);
                getNumFromFile(GameFile, NiLevel[ARCHER], unsigned short);
                getNumFromFile(GameFile, NiLevel[SWORDSMEN], unsigned short);
                getNumFromFile(GameFile, Frank.mode, modeType);
                getNumFromFile(GameFile, Frank.jumps, unsigned short);
                getNumFromFile(GameFile, Frank.multiply, unsigned short);
                getNumFromFile(GameFile, Frank.letter, unsigned short);
                getNumFromFile(GameFile, Frank.lives, unsigned short);
                getNumFromFile(GameFile, Frank.score, unsigned short);
                (Frank.newMen)= ((Frank.score)/ NEWGUYSCORE)* NEWGUYSCORE;
                getStrFromFile(GameFile, Frank.name);
                getNumFromFile(GameFile, Matt.mode, modeType);
                resetPlayer(&Frank, RIGHT, RESETOPENGAME);
                 */
             } catch (FileNotFoundException ex) {
                System.out.println(ex);
            } catch(IOException ex) {
                System.out.println(ex);
            }

               //while(true) {
                 try {
                       game= (Game)oIn.readObject();
                   } catch(ClassNotFoundException ex) {
                        //break;
                    } catch(IOException ex) {
                        //break;
                    }
               //}

               try {
                    oIn.close();
                } catch(IOException ex) {
                    System.out.println(ex);
                }
        }
        
        /**
         * Quits the Java application and the entire thing after saving necessary info.
         **/
        public void quit() {
            this.game.pause(true);
            //do pre-Quit stuff
            cleanUp();
            System.exit(0);
        }

        /**
         * does what finalize should do.
         **/
        public void cleanUp() {
            if(this.game != null) {
                game.cleanUp();
                game= null;
            }
            highScores.saveHighscores();
        }



        /** 
	 * override from Object.finalize().
	 * saves the keys preferences.
	 **/ 
        protected void finalize() throws Throwable {
            //save prefs.
            //save highscores
            cleanUp();
            
            super.finalize();
        }
}

package hero;

import java.awt.Point;
import java.awt.Dimension;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.applet.Applet;

/**
 * represents a POWER ball or Bonus Ball
 * @author  TaylorFM
 */
public class Ball extends ScreenItem {
    final char letter;
    final static int SPEED= 10;
    
    /** Creates a new instance of Ball
     * @param game Game this piece is a part of.
     * @param letter, b= Blue, r= Red, otherwise which Letter to Spell POWER. 
     **/
    public Ball(Game game, String type) {
        super(game, new Point(0,0), new Dimension(26, 26), new Point(13,13), new Dimension(10,8), POINTS.BONUSBALLSCORE);
        
        this.letter= type.charAt(0);

        DIRECTION direction= Util.randomDirection();
        
        this.direction= direction;
        
        switch(direction) {
            case LEFT:
                this.place= new Point(game.view.content.getWidth(), Util.random.nextInt(game.view.content.getHeight()));
                break;
            case RIGHT:
                this.place= new Point(0, Util.random.nextInt(game.view.content.getHeight()));
                break;
            case UP:
                this.place= new Point(Util.random.nextInt(game.view.content.getWidth()), game.view.content.getHeight());
                break;
            case DOWN:
                this.place= new Point(Util.random.nextInt(game.view.content.getWidth()), 0);
                break;
        }
        
        /*try {
            setIcons(type);
        } catch (IOException ex) {
            System.out.println(ex);
        }*/
        setIcon();
    }
    
    public void setIcon() {
        icon= icons.get(0);
    }
    
    void setIcons(String type, Applet webApp) throws IOException {
        icons.add(ImageIO.read(new File("images/bonus/"+type+".gif")));
    }
    
    public void kill() {
        alive= false;
    }
    
    boolean canKill() {
        return true;
    }
    
    boolean canDie() {
        return true;
    }
    
    public boolean kills(ScreenItem man) {
        return false;
    }   
}

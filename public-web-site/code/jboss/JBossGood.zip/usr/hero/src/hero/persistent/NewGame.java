package hero.persistent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JDialog;
import java.util.List;
import java.util.ArrayList;
import java.awt.Color;
import java.awt.Point;

import hero.Game;
import hero.Util;
import hero.Player;
/**
 *
 * @author  TaylorFM
 */
public class NewGame {
    private final JFrame parent;
    private final Game game;
    private JDialog newGameDlg= null;
    
    /** Creates a new instance of NewGame */
    public NewGame(Game game) {
        this.game= game;
        this.parent= game.view.frame;
        
        this.game.players.clear();
        
        newGameDlg= new JDialog(this.parent);
        JPanel content= (JPanel)newGameDlg.getContentPane();
        
        JButton start= new JButton("Start");
        start.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            { 
                NewGame.this.game.players.add(new Player(NewGame.this.game, "Lee", new Point(200, 100), "Red", Color.RED));
                NewGame.this.game.startGame(1- 1);
                
                newGameDlg.removeAll();
                newGameDlg.dispose();
                newGameDlg= null;
            }
        });
        
        content.add(start);
        content.getRootPane().setDefaultButton(start);
        
        newGameDlg.pack();
        newGameDlg.setSize(300, 500);
        newGameDlg.setLocation(Util.getCenteredLocation(parent.getBounds(), newGameDlg.getBounds())); 
        newGameDlg.setVisible(true);

    }
    
}

package hero;

import java.awt.Rectangle;
import java.awt.Point;
import java.io.File;
import java.io.Serializable;
import java.io.IOException;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Collection;
import java.util.Iterator;
import java.util.HashMap;
import java.awt.Image;
import java.util.prefs.Preferences;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.applet.Applet;

/**
 * describes a Good player/Ninja
 *      
 *	@author	ftaylor
 */
public class Player extends Human implements Serializable {
    /**Ways to reset the player's values**/
    public static enum resetType {RESETGAME,RESETCONTINUE,RESETINIT,RESETPRELUDE,RESETOPENGAME,RESETSETUP,RESETLEVEL}
    /**at what score do I get a new man**/
    public static final int NEWGUYSCORE= 5000;
    boolean        neverPlayed= true;
         boolean        outForever= false;
	 transient int	forceField;
         int            power;
         transient Point   scorePoint; 

         /**to save/get persistent preferences**/
         public final Preferences prefs= Preferences.userRoot().userNodeForPackage(this.getClass());

	 int	last_new_man_score= 0;
	 int	score= 0;
	 int	multiply= 1;
	 int	letter= 0;
	 int	lives= 3;
         /**this player's name**/
	 public String	name;
        
         final Color color;
         final String colorStr;

         /**Maps the keyboard keycodes to an action or direction**/
	 public Map<Integer,DIRECTION> directionKeys= new	HashMap<Integer,DIRECTION>(4);
	 public Map<Integer,ACTION> actionKeys= new	HashMap<Integer,ACTION>(4);

         /**
          * constructor for a empty, useless player (for menu items).
          * @param name name of this player
          **/
         public Player(String name) {
             super(null, null, POINTS.ZEROSCORE);
             this.color= null;
             this.colorStr= null;
             this.name= name;
         }
	 
	 /** Creates a	new instance of Player 
           * @param game game this is involved in
           * @param location where the player should be located.
           * @param name name of player
           * @param colorStr color as type-string.
           * @param color color of player
          **/
	 public Player(Game game, String name, Point location, String colorStr, Color color) {
		  super(game, location, POINTS.ZEROSCORE);

                  this.name= name;
                  this.colorStr= colorStr;
                  this.color= color;
                  this.power= 5;
                  this.jumps= 3;

                  // try {
                      getSavedKeys(null, null);
                      // setIcons(this.colorStr);
                      setIcon();
                  // } catch(IOException ex) {
                  //      System.out.printf("%s\n", ex);
                  // }
	 }
       
        /**
         * Maps keys to actions.
         * Actions are: Punch, Flip, Jump and Pause Game.
         *Gets keys from a persistent properties file or uses passed in or default values, if passed in array is null.
         * Directions are: Right, Left, Up, Down.
         * @param dirs a Map of keycodes to directions.
         * @param actions a Map of keycodes to actions.
         **/
         public void getSavedKeys(Map<Integer,DIRECTION> dirs, Map<Integer,Human.ACTION> actions) {
              final Map<Integer,DIRECTION> defDirs= getDefaultDirKeys();
              final Map<Integer,ACTION> defActs= getDefaultActionKeys();
              if(null == dirs)     dirs= defDirs;
              if(null == actions)  actions= defActs;

              directionKeys.clear();
              for(Entry<Integer,DIRECTION> dir : dirs.entrySet()) {
                  directionKeys.put(prefs.getInt(name+ dir.getValue().name(), dir.getKey()),dir.getValue());
              }

              actionKeys.clear();
              for(Entry<Integer,ACTION> act : actions.entrySet() ) {
                  actionKeys.put(prefs.getInt(name+ act.getValue().name(), act.getKey()),act.getValue());
              }

/*              prefs.getInt(name+DIRECTION.LEFT.name(), );
              
              directionKeys.put(prefs.getInt(name+"Left", keys[0][0]), DIRECTION.valueOf(keys[0][1]));
              directionKeys.put(prefs.getInt(name+"Right", keys[1][0]), DIRECTION.valueOf(keys[1][1]));
              directionKeys.put(prefs.getInt(name+"Up", keys[2][0]), DIRECTION.valueOf(keys[2][1]));
              directionKeys.put(prefs.getInt(name+"Down", keys[3][0]), DIRECTION.valueOf(keys[3][1]));

              actionKeys.clear();
              actionKeys.put(prefs.getInt(name+"Punch", keys[4][0]), Human.ACTION.valueOf(keys[4][1]));
              actionKeys.put(prefs.getInt(name+"Flip", keys[5][0]), Human.ACTION.valueOf(keys[5][1]));
              actionKeys.put(prefs.getInt(name+"Jump", keys[6][0]), Human.ACTION.valueOf(keys[6][1]));
              actionKeys.put(prefs.getInt(name+"Pause", keys[7][0]).charAt(0), Human.ACTION.valueOf(keys[7][1]));
*/ 
        }

        /**
         * saves the current keys to a persistent properties file to use next time the game is launched for this user(name).
         **/
        public void saveKeys() {
 
            for(Entry<Integer,DIRECTION> e : directionKeys.entrySet() ) {
                prefs.putInt(name+e.getValue().name(), e.getKey());
            }
            for(Entry<Integer,Human.ACTION> e : actionKeys.entrySet() ) {
                prefs.putInt(name+e.getValue().name(), e.getKey());
            }
        }

        /**
         * Maps keys to actions.
         * Actions are: Punch, Flip, Jump and Pause Game.
         * Directions are: Right, Left, Up, Down.
         * @param dirs a Map of keycodes to directions.
         * @param actions a Map of keycodes to actions.
         **/
        public void setKeys(Map<Integer,DIRECTION> dirs, Map<Integer,Human.ACTION> actions) {
              directionKeys.clear();
              directionKeys.putAll(dirs);
        
              actionKeys.clear();
              actionKeys.putAll(actions);
        }

        /** 
         * override from Object.finalize().
         * saves the keys preferences.
         **/ 
        protected void finalize() throws Throwable {
            saveKeys();
            
            super.finalize();
        }

	 /**
	  * Checks	that each screen item interacts with eachother
          * checkWater()
	  * @param enemies list of enemies.
	  **/
	 void	checkDeaths(List<Enemy>	enemies, List<ScreenItem> ordinance)
	 {
            checkPassages(game.view.gameBoard.player_Port);

            if(checkWater()) {
                //doSound(DROWNEDSOUND);
                //icon= drowned
                die();
            } else if(!this.isDead()) {
                //check each enemy and me don't kill, or be killed
                List<ScreenItem> allPieces= new ArrayList<ScreenItem>();
            
                allPieces.addAll(enemies);
                allPieces.addAll(ordinance);

                for(ScreenItem enemy : allPieces) {

                    if(this.kills(enemy)) {
                        this.score+= enemy.points.score * multiply;
                        if((score - last_new_man_score) >= NEWGUYSCORE)
                        {
                            last_new_man_score+= NEWGUYSCORE;
                            lives++;
                            //doSound(NEWGUYSOUND);
                        }
                        enemy.die();
                    } else if(enemy.kills(this)) {
                        this.die();
                    }
                }
            }

            if(true)    //debug
                return;

//----old check deaths code.
            Point forgetPoint;
              /*Checks enemy's deaths*/
              for(int b= 0; b	< enemies.size();	b++)
              {
                        Enemy	Bad= enemies.get(b);

                        if(Bad.canDie())
                         {
                             if((Bad.type) == Enemy.TYPE.SWORDSMEN && Bad.kind.compareTo(Enemy.KIND.STAB) > 0 ) {
                                //checkTridentDeaths(Bad,	this);
                             }
                             
                             if((Bad.action)	==	ACTION.PUNCH	&&	(Bad.direction) == DIRECTION.LEFT) {
                                forgetPoint= new Point(Bad.place.x+	4,	Bad.place.y);
                             } else {
                                forgetPoint= new Point((Bad.place).x, (Bad.place).y);
                             }
                             if(killZone.contains(forgetPoint))
                             {
                                 if((Bad.action)	==	ACTION.PUNCH) {
                                     Bad.place.x= Bad.place.x+ IconNum.H_HUMAN- this.size.width;	//Make sure	punch	size is regular size	for InsetRect
                                 }
                                 (Bad.action)=ACTION.DIE;
                                 Bad.killZone.setBounds(0,0,0,0);	//so no double	deaths
                                 score+= Bad.points.ordinal()* multiply;
                                 //doSound(HITSOUND);
                         }
                  } /*if(Bad<LASTPUNCH)*/

                 /*check	for Players' death*/						
                 if(this.canDie() && Bad.canKill())
                 {
                            if(action	==	ACTION.PUNCH	&&	direction == DIRECTION.LEFT) {
                                forgetPoint= new Point(place.x+ 14, place.y);
                            } else {
                                forgetPoint= new Point(place.x, place.y);
                            }
                            if(Bad.killZone.contains(forgetPoint))
                              {
                                  //if(action == ACTION.PUNCH)	((place).right)= ((place).x)+ H_HUMAN;	//Make sure	punch	size is regular size	for InsetRect
                                  action=	ACTION.DIE;
                                  icon=	icons.get(IconNum.DEADNUM);
                                  //place.x+= HDIE;
                                  //place.y+= VDIE;
                                  //doSound(KILLEDSOUND);
                              }
                 } /*if(Good<LASTPUNCH)*/
             }//for(Enemies)
	 }
	 
	 /** 
	  * checks	specific	type of death
	  * @param Bad list of enemies.
	  * @param Good player to compare to list of enemies.
	  **/
	 void	checkTridentDeaths(List<Enemy> Bad,	Player Good)
	 {
		  /*switch(Bad.kind)
				{
				case STABOUT1:
				case STABIN1:
						  switch(Bad.dir)
									 {
									 case	LEFT:
												forgetRect=	InOffSet(Bad.place, 4, 24,	-25, 0);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (TRIDENTSCORE* (Good.multiply));
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												break;
									 case	UP:
												forgetRect=	InOffSet(Bad.place, 9, 19,	0,	-20);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (TRIDENTSCORE* (Good.multiply));
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												break;
									 case	RIGHT:
												forgetRect=	InOffSet(Bad.place, 4, 24,	25, 0);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (TRIDENTSCORE* (Good.multiply));					
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												break;
									 default:	//DOWN
												forgetRect=	InOffSet(Bad.place, 9, 19,	0,	0);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (TRIDENTSCORE* (Good.multiply));										
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												break;
									 }
						  break;
				case STABOUT2:
				case STABIN2:
						  switch(Bad.dir)
									 {
									 case	LEFT:
												forgetRect=	InOffSet(Bad.place, 4, 24,	-25- 22,	0);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (TRIDENTSCORE* (Good.multiply));										
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												forgetRect=	InOffSet(forgetRect,	2,	4,	22, 0);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (SHAFTSCORE*	(Good.multiply));										
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												break;
									 case	UP:
												forgetRect=	InOffSet(Bad.place, 9, 19,	-22, -20);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (TRIDENTSCORE* (Good.multiply));										
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												forgetRect=	InOffSet(forgetRect,	4,	2,	22, 0);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (SHAFTSCORE*	(Good.multiply));										
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												break;
									 case	RIGHT:
												forgetRect=	InOffSet(Bad.place, 4, 24,	25+ 22, 0);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (TRIDENTSCORE* (Good.multiply));										
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												forgetRect=	InOffSet(forgetRect,	2,	4,	-22, 0);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (SHAFTSCORE*	(Good.multiply));										
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												break;
									 default:	//DOWN
												forgetRect=	InOffSet(Bad.place, 9, 19,	22, 0);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (TRIDENTSCORE* (Good.multiply));										
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												forgetRect=	InOffSet(forgetRect,	4,	2,	-22, 0);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (SHAFTSCORE*	(Good.multiply));					
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												break;
									 }
						  break;
				case STABOUT3:
				case STABIN3:
						  switch(Bad.dir)
									 {
									 case	LEFT:
												forgetRect=	InOffSet(Bad.place, 4, 24,	-25- 44,	0);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (TRIDENTSCORE* (Good.multiply));					
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												forgetRect=	InOffSet(forgetRect,	2,	4,	22, 0);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (SHAFTSCORE*	(Good.multiply));					
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												OffsetRect(&forgetRect,	22, 0);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (SHAFTSCORE*	(Good.multiply));					
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												break;
									 case	UP:
												forgetRect=	InOffSet(Bad.place, 9, 19,	-44, -20);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (TRIDENTSCORE* (Good.multiply));					
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												forgetRect=	InOffSet(forgetRect,	4,	2,	0,	22);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (SHAFTSCORE*	(Good.multiply));					
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												OffsetRect(&forgetRect,	0,	22);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (SHAFTSCORE*	(Good.multiply));					
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												break;
									 case	RIGHT:
												forgetRect=	InOffSet(Bad.place, 4, 24,	25+ 44, 0);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (TRIDENTSCORE* (Good.multiply));					
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												forgetRect=	InOffSet(forgetRect,	2,	4,	-22, 0);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (SHAFTSCORE*	(Good.multiply));					
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												OffsetRect(&forgetRect,	-22, 0);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (SHAFTSCORE*	(Good.multiply));					
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												break;
									 default:	//DOWN
												forgetRect=	InOffSet(Bad.place, 9, 19,	44, 0);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (TRIDENTSCORE* (Good.multiply));					
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												forgetRect=	InOffSet(forgetRect,	4,	2,	0,	-22);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (SHAFTSCORE*	(Good.multiply));					
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												OffsetRect(&forgetRect,	0,	-22);
												if(PtInRect(topLeft(forgetRect),	&(Good.killZone)))
														  {
														  (Bad.kind)=STABDONE;
														  makeRectEmpty(Bad.killZone);	//so no double	deaths
														  (Good.score)+= (SHAFTSCORE*	(Good.multiply));					
														  placePoints(forgetRect);
														  doSound(BREAKTRIDENTSOUND);
														  }
												break;
									 }
						  break;
				default:	//no trident plotted
						  break;
				}*/
	 }
 
         /**
          * @see Human.canDie()
          * includes Force Field functionality.
          **/
        public boolean canDie() {
            return (super.canDie() && 0 == forceField);
        }

        /**
         * calls Human.setIcons
         * @see Human.setIcons
         **/
        public void setIcons(String colorStr, Applet webApp) throws IOException {
            Human.setIcons(this.icons, colorStr, webApp);
        }
        
        /**
         * @return the default Map of keycodes to DIRECTIONs
         **/
        public static Map<Integer,DIRECTION> getDefaultDirKeys() {
            Map<Integer,DIRECTION> keys= new HashMap<Integer,DIRECTION>(4);
            
            keys.put(KeyEvent.VK_J, DIRECTION.LEFT);
            keys.put(KeyEvent.VK_L, DIRECTION.RIGHT);
            keys.put(KeyEvent.VK_I, DIRECTION.UP);
            keys.put(KeyEvent.VK_K, DIRECTION.DOWN);
            
            return keys;
        }
        
        /**
         * @return the default Map of keycodes to ACTIONs
         **/
       public static Map<Integer,ACTION> getDefaultActionKeys() {
            Map<Integer,Human.ACTION> keys= new HashMap<Integer,Human.ACTION>(4);
            
            keys.put(KeyEvent.VK_S, Human.ACTION.PUNCH);
            keys.put(KeyEvent.VK_D, Human.ACTION.FLIP);
            keys.put(KeyEvent.VK_F, Human.ACTION.JUMP);
            keys.put(KeyEvent.VK_SPACE, Human.ACTION.PAUSE);
            
            return keys;
        }
        
       /**
        * @return how this player should be seen as text.
        **/
        public String toString() {
            return name;
        }
        
    /**
     * resets player's settings
     * @param dir which direction this player should be facing.
     * @param type way to reset the player's values.
     **/
    void reset(final DIRECTION dir, final resetType type)
    {
        direction= dir;
        //(iconNum)= getIconNum(STAND, dir);
        //killZone= empty;

        switch(type)
        {
        case RESETGAME:
        case RESETCONTINUE:
                letter= 31;
                alive= true;
                //mode= ACTION.STAND;
                action= ACTION.STAND;
                last_new_man_score= 0;
                score= 0;
                lives= 3;
                jumps= 0;
                multiply= 1;
                //makeRectEmpty(killZone);
                break;
        case RESETINIT:
                letter= 31;
                alive= false;
                last_new_man_score= 0;
                score= 0;
                lives= 3;
                jumps= 0;
                multiply= 1;
                action= ACTION.STAND; //mode= NEVERPLAYED;
                place= /*(oldPlace)= (killZone)=*/ new Point(0,0);
                break;
        case RESETPRELUDE:
                alive= true;
                //mode= STAND;
                //oldPlace= (place);
                //makeRectEmpty(killZone);
                freezer= 0;
                forceField= 0;
                break;
        case RESETOPENGAME:
                alive= true;
                break;
        case RESETSETUP:
                //jumps+= ((NiLevel[NINJA])- 1);
                multiply= 1;
                break;
        default:
                break;
        }
    }
    
    public void kill() {
        super.kill();
        
        this.lives--;
        
        if(0 == lives) {
            outForever= true;
        }
        
        this.game.level.arePlayersDead();
    }

}

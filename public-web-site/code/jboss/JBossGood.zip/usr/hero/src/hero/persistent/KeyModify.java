package hero.persistent;

import hero.Player;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Map.Entry;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Component;
import javax.swing.ImageIcon;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.event.PopupMenuListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.border.BevelBorder;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenuItem;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyAdapter;

import hero.Util;
import hero.ScreenItem.DIRECTION;
import hero.Human.ACTION;

/**
 * Modifies a Player's control keys
 * @author  TaylorFM
 */
public class KeyModify {
    private final List<Player> players;
    private final JFrame parent;
    private JDialog modDlg= null;
    public JComboBox playerMenu;
    int theValue = 0;
    private Player currentPlayer= null;
    KeyInputPanel keyInput;
    JTextField  name;
    private Player current_player= null;
    private final Box storeys= Box.createVerticalBox();

    /** Creates a new instance of KeyModify */
    public KeyModify(final JFrame parent, final List<Player> players) {
        this.parent= parent;
        this.players= players;
    }

    public void modifyKeys() {
        modDlg= new JDialog(parent);

        JPanel prefPane= (JPanel)modDlg.getContentPane();

        storeys.removeAll();
        //all.add(new JLabel(new ImageIcon("images/windows/preferences.jpg")));
        current_player= players.get(0); //menu selection here
        keyInput= new KeyInputPanel(current_player);
        
        JLabel playerLabel= new JLabel("Player:", JLabel.RIGHT);
        playerMenu= new JComboBox(players.toArray());
        playerMenu.addItem(new Player("Create New Player"));
        playerLabel.setLabelFor(playerMenu);
        playerMenu.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e)
            { 
                Player man= (Player)playerMenu.getSelectedItem();
                KeyModify.this.perPerson(man);
            }
        });
        
        storeys.add(playerMenu);

        prefPane.add(storeys);
        modDlg.pack();
        modDlg.setSize(300, 500);
        modDlg.setLocation(Util.getCenteredLocation(parent.getBounds(), modDlg.getBounds())); 
        modDlg.setVisible(true);
    }
    
    public void perPerson(Player player) {
        currentPlayer= player;
        
        JLabel nameLabel= new JLabel("Name:", JLabel.RIGHT);
        name= new JTextField(10);
        nameLabel.setLabelFor(name);
        name.setText(current_player.name);
        name.setSize(50,20);

        
        storeys.add(name);
        storeys.add(keyInput);
        
        /*for(Player man : players) {
            JMenuItem selection= new JMenuItem(man.name);
            playerMenu.add(selection);
            selection.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    //KeyModify.this.currentPlayer= man; 
                }
            });
        }*/

        //playerMenu.setLabel("Which Player");
        //playerMenu.setBorder(new BevelBorder(BevelBorder.RAISED));

        //playerMenu.addPopupMenuListener(new PopupPrintListener());

        //prefPane.addMouseListener(new MousePopupListener());
        //all.add(playerMenu);

        //playerMenu.show(all, 20, 40);
        
        modDlg.repaint();
    }

    public void setKeys(boolean save) {
        if(save) {
            
        }

        modDlg.removeAll();
        modDlg.dispose();
        modDlg= null;
    }

    /* Inner class to check whether mouse events are the popup trigger
    class MousePopupListener extends MouseAdapter {
        public void mousePressed(MouseEvent e) { checkPopup(e); }
        public void mouseClicked(MouseEvent e) { checkPopup(e); }
        public void mouseReleased(MouseEvent e) { checkPopup(e); }

        private void checkPopup(MouseEvent e) {
            if (e.isPopupTrigger()) {
                playerMenu.show(KeyModify.this.modDlg, e.getX(), e.getY());
            }
        }
    }*/

    // Inner class to print information in response to popup events
    class PopupPrintListener implements PopupMenuListener {
        public void popupMenuWillBecomeVisible(PopupMenuEvent e) { }

        public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
            theValue = 1;//slider.getValue();
            System.out.println("The value is now " + theValue);
        }

        public void popupMenuCanceled(PopupMenuEvent e) {
            System.out.println("Popup menu is hidden!");
        }
    }
    
    public class KeyInputPanel extends JPanel {
        private int whichKey= 0;
        //private DIRECTION lastDirection= null;
        //private ACTION lastAction= null;
        private int lastKey= 0;
        private JLabel lastLabel= null;
        //DIRECTION lastDirectionType;
        //ACTION lastActionType;
        
        private final Player player;
        private Map<Integer,DIRECTION> directionKeys= new HashMap<Integer,DIRECTION>();
        private Map<Integer,ACTION> actionKeys= new HashMap<Integer,ACTION>();
        
        Map<DIRECTION, JLabel> dirLabels= new HashMap<DIRECTION, JLabel>(8);
        Map<ACTION, JLabel> actLabels= new HashMap<ACTION, JLabel>(8);
        List<DIRECTION> dirOrder= new ArrayList<DIRECTION>(4);
        List<ACTION> actOrder= new ArrayList<ACTION>(4);
        List<Integer> keyOrder= new ArrayList<Integer>(8);
        
        public KeyInputPanel(Player player) {
            this.player= player;
            
            directionKeys.putAll(player.directionKeys);
            actionKeys.putAll(player.actionKeys);
            
            this.setLayout(new BoxLayout(KeyInputPanel.this, BoxLayout.PAGE_AXIS ));//Box.createVerticalBox();
            this.add(new JLabel("Type Highlighted Key"), Component.LEFT_ALIGNMENT);
            this.add(new JLabel("or <TAB> to leave unchanged"), Component.LEFT_ALIGNMENT);
            for(Entry<Integer, DIRECTION> pair : directionKeys.entrySet()) {
                Box keyPair= Box.createHorizontalBox();
                JLabel val= new JLabel(KeyEvent.getKeyText(pair.getKey()));
                if(null == lastLabel)   {
                    lastLabel= val;
                    lastLabel.setForeground(Color.RED);
                    lastKey= pair.getKey();
                    //lastDirection= pair.getValue();
                }
                JLabel act= new JLabel(" - "+ pair.getValue().name()+ " key");
                dirLabels.put(pair.getValue(), val);
                dirOrder.add(pair.getValue());
                keyOrder.add(pair.getKey());
                //dirLabels.put(pair.getValue(), act);
                keyPair.add(val);
                keyPair.add(act);
                this.add(keyPair, Component.LEFT_ALIGNMENT);
            }

            for(Entry<Integer, ACTION> pair : actionKeys.entrySet()) {
                Box keyPair= Box.createHorizontalBox();
                JLabel val= new JLabel(KeyEvent.getKeyText(pair.getKey()));
                JLabel act= new JLabel(" - "+ pair.getValue().name()+ " key");
                actLabels.put(pair.getValue(), val);
                actOrder.add(pair.getValue());
                keyOrder.add(pair.getKey());
                //actLabels.put(pair.getValue(), act);
                keyPair.add(val);
                keyPair.add(act);
                this.add(keyPair, Component.LEFT_ALIGNMENT);
            }

            
            Box buttons= Box.createHorizontalBox();
            JButton nextButton= new JButton("next");
            JButton cancelButton= new JButton("Close");
            JButton okButton= new JButton("Apply");
            JButton defaultButton= new JButton("defaults");
            okButton.addActionListener( new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    KeyInputPanel.this.player.actionKeys= KeyInputPanel.this.actionKeys;
                    KeyInputPanel.this.player.directionKeys= KeyInputPanel.this.directionKeys;
                    KeyInputPanel.this.player.name= KeyModify.this.name.getText();
                }
            });
            cancelButton.addActionListener( new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    //KeyModify.this.modDlg.dispose();
                    KeyModify.this.setKeys(false);
                }
            });
            nextButton.addActionListener( new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    KeyInputPanel.this.changeNextKey(-1);
                    KeyInputPanel.this.requestFocus();
                }
            });
            defaultButton.addActionListener( new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    KeyInputPanel.this.directionKeys= Player.getDefaultDirKeys();
                    KeyInputPanel.this.actionKeys= Player.getDefaultActionKeys();
                }
            });
            buttons.add(nextButton);
            buttons.add(cancelButton);
            buttons.add(okButton);
            buttons.add(defaultButton);
            
            this.add(buttons);
            
            dirLabels.get(dirOrder.get(whichKey)).setForeground(Color.RED);
            
            //add(allKeys);
            
            setSize(100, 100);
            
            this.addKeyListener(new KeyListener() {
                public	void keyPressed(KeyEvent e) {
                    changeNextKey(e.getKeyCode());
                    
                }
                public	void keyReleased(KeyEvent e) {
                    
                }
                public	void keyTyped(KeyEvent e) {
                }
                
            });
            
            this.setFocusable(true);
            requestFocus();
        }
        
        void changeNextKey(int key) {
            //change last key
            //last label
            //last.DIR or last.ACT
            
            //whether the key is a Direction or an Action key
            boolean isAction= whichKey >= dirOrder.size();
            
            //JLabel keyLabel;
            //int oldKey= directionKeys.
            
            /*if(isAction) {
                lastLabel= dirLabels.get(dirOrder.get(whichKey));
            } else {
                lastLabel= actLabels.get(actOrder.get(whichKey-dirOrder.size()));
            }*/
            lastLabel.setForeground(Color.BLACK);
            
            //lastLabel.setForeground(Color.BLACK);
            if(key != -1) {
                lastLabel.setText(KeyEvent.getKeyText(key));
                if(isAction) {
                    //ACTION lastActionType= actionKeys.get(lastKey);
                    actionKeys.remove(keyOrder.get(whichKey));
                    actionKeys.put(key, actOrder.get(whichKey- dirOrder.size()));
                    //remeber for next round
                    //lastAction= actionKeys.get(key);
                    //lastActionType= actionKeys.get(lastKey);
                } else {
                   //DIRECTION lastDirectionType= directionKeys.get(lastKey);
                    directionKeys.remove(keyOrder.get(whichKey));
                    DIRECTION duplicateType= directionKeys.get(key);
                    if(duplicateType != null)   directionKeys.put(KeyEvent.VK_DEAD_IOTA, duplicateType);
                    directionKeys.put(key, dirOrder.get(whichKey));
                    //lastDirection= directionKeys.get(key);
                    //lastDirectionType= directionKeys.get(key);
                    //System.out.printf("lastKey:%s key:%s lastDirection:%s lastDirectionType:%s\n", KeyEvent.getKeyText(lastKey), KeyEvent.getKeyText(key), lastDirection.name(), lastDirectionType.name());
                }                
            }
            
            lastKey= key;
            keyOrder.set(whichKey, key);
            
            //goto the next field to remember the values
            whichKey= (whichKey+1) % (dirOrder.size()+actOrder.size());
            isAction= whichKey >= dirOrder.size();
            
            if(isAction) {
                lastLabel= actLabels.get(actOrder.get(whichKey-dirOrder.size()));
            } else {
                lastLabel= dirLabels.get(dirOrder.get(whichKey));
            }
            //keyLabel.setText("press key");
            lastLabel.setForeground(Color.RED);
            
            /*---------DEBUG-----------
            for(Entry<Integer,DIRECTION> e : directionKeys.entrySet()) {
                System.out.printf("%s:%s\n", KeyEvent.getKeyText(e.getKey()), e.getValue());
            }
            System.out.println("---");*/
        }
        
        
    }
    
}

package hero;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Image;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Random;
import java.util.Properties;
import java.util.GregorianCalendar;
import java.applet.Applet;
import java.net.URL;
import java.net.MalformedURLException;
import hero.ScreenItem.DIRECTION;

/**
 * un-attributeable classes
 * @author  TaylorFM
 */
public class Util {
    static {
        /* try {
            Util.strRes= new Properties();
            Util.strRes.load(new FileInputStream("C:/development/fava/hero/strings.txt"));
        } catch (IOException ex) {
            System.out.println(ex);
            //Util.strRes= null;
        } */
    }
    
    /**
     *  given a big rectangle, give the upper corner fo a smaller rectangle, so that the smaller rect will be centered on the larger.
     * @param big larger rect to be used to center other rectangle.
     * @param small smaller rectangle to center on larger rectangle.
     * @return the upper, left corner (or location) of the smaller, centered rectabgle.
     **/
    public static Point getCenteredLocation(Rectangle big, Rectangle small) {
        int x= ((big.width- small.width)/ 2)+ big.x;
        int y= ((big.height- small.height)/ 2)+ big.y;

        return new Point(x,y);
    }

    /**
     * returns if the number is even.
     * @param x number to determine if even.
     * @return if x is an even number.
     **/
    public static boolean isEven(final int x) {
        return(x/2 == Math.round(x/2));
    }

    /**
     * @returns the angle point one makes with point two
     * @ deprecated
     **/
    public static double angle(Point one, Point two) {
        return Math.atan((Math.abs(one.y-two.y)/Math.abs(one.x-two.x)));
    }

    /** Random number generator
     * use like this: Util.random.nextInt(x), where and integer between 0 and x-1, but never x, is returned;
     **/
    public static Random random= new Random(new GregorianCalendar().getTimeInMillis());

    /**
     * Strings stored in a file.  Use like this Util.strRes.get("GAME_OVER"), returns: "Game Over"
     **/
    public static Properties strRes;
    /**
     * returns the most direct direction to get to destination.
     * @param me where you are now.
     * @param destination where you want to point towards.
     * @return direction to point towards destination.
     **/
    public static DIRECTION direct(Point me, Point destination, int precision) {
        if(me.y+ precision > destination.y)    return DIRECTION.UP;
        else if(me.y- precision < destination.y)    return DIRECTION.DOWN;
        else if(me.x+ precision < destination.x)    return DIRECTION.RIGHT;
        else if(me.x- precision > destination.x)    return DIRECTION.LEFT;
        else return DIRECTION.NONE;
    }
    
    /**
     * @return a DIRECTION at random, but never NONE.
     **/
    public static DIRECTION randomDirection() {
        return (DIRECTION.values())[random.nextInt(DIRECTION.values().length-1)];
        
        /*switch(random.nextInt(4)) {
            case 0:
                return DIRECTION.LEFT;
            case 1:
                return DIRECTION.RIGHT;
            case 2:
                return DIRECTION.UP;
            case 3:
                return DIRECTION.DOWN;
            default:
                return DIRECTION.NONE;
        }*/
        
    }
    
    protected static ImageIcon loadImage(String path, Applet webApp) {
        System.out.println("DBASE:"+ webApp.getDocumentBase());
        System.out.println("CBASE:"+ webApp.getCodeBase());
        //return new ImageIcon(webApp.getImage(webApp.getDocumentBase(), "../../"+ path));
        ImageIcon icon= null;
        try {
            icon= new ImageIcon(webApp.getImage(new URL(webApp.getCodeBase()+"/../"+path)));
        } catch(MalformedURLException ex) {
            System.out.println(ex);
        }
        return icon;
    }
    
    /**
     * Returns an Image for use in loading images in a web Applet
     * @param path file to return as Java Image
     * @return image 
     **/
    protected static ImageIcon xloadImage(String path) 
    {
        int MAX_IMAGE_SIZE = 131072;  //Change this to the size of
                                     //your biggest image, in bytes.
        int count = 0;
        BufferedInputStream imgStream = new BufferedInputStream(
           Webo.class.getResourceAsStream(path));
        if (imgStream != null) {
            byte buf[] = new byte[MAX_IMAGE_SIZE];
            try {
                count = imgStream.read(buf);
                imgStream.close();
            } catch (java.io.IOException ioe) {
                System.err.println("Couldn't read stream from file: " + path);
                return null;
            }
            if (count <= 0) {
                System.err.println("Empty file: " + path);
                return null;
            }
            return new ImageIcon(Toolkit.getDefaultToolkit().createImage(buf));    //new ImageIcon()
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }
}

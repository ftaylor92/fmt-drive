package hero.persistent;

import java.io.Serializable;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author  TaylorFM
 */
    public class Score implements Comparable<Score>, Serializable {
        public String name;
        public int level, score;

        public Score() {
            //for Serializable only
            this("unknown", 0, 0);
        }

        public Score(String name, int level, int score) {
            this.name= name;
            this.level= level;
            this.score= score;
        }

        public int compareTo(Score otherScore) {
            int levelCompare= 0;
            if(otherScore.level > this.level)   levelCompare= 1;
            if(otherScore.level < this.level)   levelCompare= -1;

             
            if(otherScore.score > this.score) return 1;
            if(otherScore.score < this.score) return -1;

            return levelCompare;
        }


}

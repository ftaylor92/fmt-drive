package hero;

import java.awt.Rectangle;
import java.awt.Point;
import java.awt.Dimension;
import java.awt.Image;
import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Arrays;
import java.io.File;
import javax.imageio.ImageIO;
import java.applet.Applet;
import hero.ScreenItem.DIRECTION;

/**
 * represents a human, whether good or bad.
 *	@author	ftaylor
 */
public abstract class Human extends	ScreenItem {
         transient protected DIRECTION    futureDirection;
         transient protected ACTION       futureAction;
         transient int freezer;
        //All Speeds must be even for Integer division by 2
        public final static int H_FLIP_DISTANCE= 30;
        public final static int V_FLIP_DISTANCE= 26;
        public final static int H_JUMP_DISTANCE= 34;
        public final static int V_JUMP_DISTANCE= 32;
        public final static int H_WALK_DISTANCE= 15;
        public final static int V_WALK_DISTANCE= 12;

        final static int	PAPRESSPACE=5;
        //Death Zones CODE= [K=Kill] [TYPE] [DIR] [LTRB=Left,Top,Right,Bottom]
        final static int	PPRADD=		7;
        final static int	PPLADD=		28;
        final static int	PPUADD=		36;
        final static int	PPDADD=		9;
        int	jumps;
        
        public final int V_KILL_TOLERANCE= 23;
        public final int H_KILL_TOLERANCE= 22;
        //public final static int PROXIMITY= 10;

        transient boolean        pushed= false;  //wants to move
        transient boolean        tack= true; //change direction of action

        /**Helps map the icons in this.icons for numbers, to avoid String to Icon Mapping**/
        public static enum ICONNUM {
            PUNCH, FLIP, JUMP, STAND, WALK, WALK2, DUKES
        }
        /**number in this.icons of image of Dead man.**/
        public final static int DEADICONNUM= ICONNUM.values().length* 4;

        /**what actions can be done by the man**/
        public static enum ACTION { STAND, WALK, PUNCH, FLIP, JUMP, DIE, NONE, PAUSE, CUT }
         /**what action is currently being done by the man**/
        protected ACTION action;

        public void die() {
            super.die();
            
            this.action= ACTION.DIE;
            this.step= 0; //this.tack= true;
        }

        /**
         * @return whether this person is dead.
         **/
        public boolean isDead() {
            return this.action.equals(ACTION.DIE);
        }
        
        public void kill() {
            alive= false;
        }
        
        /**
         * @see super.move()
         * moves the player one step.  Set's it's appearance.  Tracks it's jumps, etc.
         **/
        public void move() {
            //getKeys, and	make players move: if key corresponds w/Map of any	Plater, then change/move
            //move, reset movement, if hit wall or barrier
            setDirection(futureDirection);
            setAction(futureAction);
            //reset action requests for next move
            //setFutureDirection(DIRECTION.NONE);
            setFutureAction(ACTION.NONE);

            //If I tacked, then reset what step I'm on
           if(tack) {
                step= 0;
                tack= false;
            } else { 
                step++;
            }

            //show the player's icon based on what step he's on
            setIcon();
 
            //reset all other values
            pushed= false;
        }

        /**
         * @return if this person is jumping, etc. so he cannot change what he's doing.
         **/
        protected boolean canChange() {
            if( (action.equals(ACTION.PUNCH) || action.equals(ACTION.FLIP) || action.equals(ACTION.JUMP) ) &&
                0 == step )
               return false;
            if(1 == step && action.equals(ACTION.JUMP))
                return false;
            if(action.equals(ACTION.DIE) || action.equals(ACTION.CUT))
                return false;

            return true;
        }
	 
	 Rectangle		  oldPlace= null;
	 Rectangle		  killZone= new Rectangle();
  
       int moveOffsetX= 0, moveOffsetY= 0;

	 /** Creates a	new instance of Human 
          * @param game this person is involved in
          **/
	 public Human(Game game, Point location, POINTS points) {
            super(game, location, new Dimension(66, 33), new Point(45,90), new Dimension(H_WALK_DISTANCE,V_WALK_DISTANCE), points);

            this.action= ACTION.STAND;
            this.setFutureDirection(DIRECTION.NONE);
            this.setFutureAction(ACTION.NONE);

            killZone= new Rectangle();  //empty Rectangle
	 }

        public boolean kills(ScreenItem opponent) {
            if(!opponent.canDie() || this.isDead())  return false;
            
            if(this.action.equals(ACTION.PUNCH)) {
                switch(direction) {
                    case LEFT:
                        if(this.place.x+ IconNum.H_INFRONT_BUFFER < opponent.place.x) return false;
                        break;
                    case RIGHT:
                        if(this.place.x+ IconNum.H_INFRONT_BUFFER > opponent.place.x) return false;
                        break;
                    case UP:
                        if(this.place.y+ IconNum.V_INFRONT_BUFFER < opponent.place.y) return false;
                        break;
                    case DOWN:
                        if(this.place.y+ IconNum.V_INFRONT_BUFFER > opponent.place.y) return false;
                        break;
                }
            }

            /*switch(direction) {
                case LEFT:
                case RIGHT:
                    V_HIT= Math.abs(opponent.place.y- this.place.y) < V_KILL_TOLERANCE;
                    /*break;
                case UP:
                case DOWN:
                    break;
            }

            if( LEFT PUNCH) {
                inFront= this.place.x- 10- opponent.place.x;
                if( inFront >= 0 && inFront < H_KILL_TOLERANCE ) {
                    if( V_HIT )
                        return true;
                }
            }*/

            boolean H_HIT= Math.abs(opponent.place.x- this.place.x) < H_KILL_TOLERANCE;
            boolean V_HIT= Math.abs(opponent.place.y- this.place.y) < V_KILL_TOLERANCE;

            return V_HIT && H_HIT && this.canKill();
        }

        /**
         * @return whether this person can die now.
         **/
        public boolean canDie() {
            if(action.equals(ACTION.DIE))
                return false;
            if( (action.equals(ACTION.FLIP) || action.equals(ACTION.JUMP) ) &&
                0 == step )
               return false;
            if(1 == step && action.equals(ACTION.JUMP))
                return false;

            /*Bad.mode.compareTo(Human.LASTPUNCH) <= 0  &&
            Bad.points.compareTo(Enemy.POINTS.IMMORTAL) != 0 &&
            killZone.x+ killZone.width > 0 ||
            forceField*/

            return true;
        }

        /**
         * see super.canKill()
         * wheter a human can kill now
         * @return whether a player can kill now.
         **/
        boolean canKill() {
             if( (action.equals(ACTION.PUNCH) || action.equals(ACTION.FLIP) || action.equals(ACTION.JUMP) ) &&
                0 == step )
               return true;
            if(1 == step && action.equals(ACTION.JUMP))
                return true;
           
            //mode.compareTo(LASTPUNCH) <= 0 && !Bad.killZone.isEmpty() && (!forceField)
            
            return false;
        }

        /**
         * Transports this person from one port to the other, if they are in one.
         * @param Two-dimensional array of Rectangles describing the two ports.
         **/
        public void checkPassages(Rectangle[] ports) {
            if(ports[0].contains(this.place)) {
                this.place.setLocation(ports[1].x, ports[1].y);
            } else if(ports[1].contains(this.place)) {
                this.place.setLocation(ports[0].x, ports[0].y);
            }
        }
        
        /**
         * sets the man to keep walking in the same direction as he's currently pointing.
         **/
        public void keepWalkling() {
            setFutureDirection(this.direction);
            setFutureAction(ACTION.NONE);
        }

         /**
          * Sets the direction the player is facing.
          * @param direction which direction to turn the player.
          **/
         public void setDirection(DIRECTION direction) { 
            
            if(canChange()) //(action) >= ACTION.JUMP2 || (action) == ACTION.APRES
            {
                if(direction.equals(DIRECTION.NONE)) {
                    this.pushed= false;
                } else {
                    this.tack= this.tack || !this.direction.equals(direction);

                    super.setDirection(direction);
                    this.pushed= true;
                    //System.out.println("DIR");
                }
             }
         }

        /**
         * places a set of images, based on type, into a list.
         * @param icons list to place images into
         * @param type which folder under images/ to get images from.
         **/
        public static void setIcons(final List<Image> icons, String type, Applet webApp) throws IOException {
            icons.clear();
            final String parentDir= "images/"+type+"/"; //C:/development/fava/hero/
            Collection<DIRECTION> dirs= Arrays.asList(DIRECTION.LEFT,DIRECTION.RIGHT,DIRECTION.UP,DIRECTION.DOWN); //directionKeys.values();
            //can I iterate over an enum?
            Collection<ICONNUM> acts= Arrays.asList(ICONNUM.PUNCH, ICONNUM.FLIP, ICONNUM.JUMP, ICONNUM.STAND, ICONNUM.WALK, ICONNUM.WALK2, ICONNUM.DUKES);

            int place= 0;
            //for(Iterator<ICONNUM> a=acts.iterator(); a.hasNext();) {
            for(ICONNUM anAct : acts) {
                //ICONNUM anAct= a.next();
                //for(Iterator<DIRECTION> d=dirs.iterator(); d.hasNext();) {
                for(DIRECTION dir : dirs) {
                    String iconName= dir+anAct.name();
                    //try {
                        //icons.put(iconName, ImageIO.read(new File(parentDir+iconName+".gif")));
                        //icons.add(ImageIO.read(new File(parentDir+iconName+".gif")));
                        icons.add(Util.loadImage(parentDir+iconName+".gif", webApp).getImage());
                    //} catch(IOException ex) {
                    //    System.out.println(ex);
                    //}
                    //icons.put(iconName, new ImageIcon(parentDir+iconName+".gif").getImage());
                }
            }

            icons.add(ImageIO.read(new File(parentDir+ "DEAD"+ ".gif")));
        }

        /**
         * takes any automatic next steps for people in the middle of an action.
         **/
        public void nextStep() {
            if( step < 3 ) {
                switch(action) {
                    case FLIP:
                        switch(direction) {
                            case LEFT:
                                     place.translate(-H_FLIP_DISTANCE, 0);
                               break;
                            case RIGHT:
                                     place.translate(H_FLIP_DISTANCE, 0);
                               break;
                            case UP:
                                     place.translate(0, -V_FLIP_DISTANCE);
                               break;
                            case DOWN:
                                    place.translate(0, V_FLIP_DISTANCE);
                                break;
                        }
                        break;
                    case JUMP:
                        switch(direction) {
                            case LEFT:
                                     place.translate(-H_JUMP_DISTANCE, 0);
                               break;
                            case RIGHT:
                                     place.translate(H_JUMP_DISTANCE, 0);
                               break;
                            case UP:
                                     place.translate(0, -V_JUMP_DISTANCE);
                               break;
                            case DOWN:
                                    place.translate(0, V_JUMP_DISTANCE);
                                break;
                        }
                        break;
                }
            }
        }

        
        public void setIcon() {
             switch(action) {
                case WALK:
                    if( pushed ) {
                        switch(step % 4) {
                            case 1:
                            case 3:
                                iconNum= direction.ordinal()+ ICONNUM.STAND.ordinal()* 4;
                                break;
                            case 2:
                                iconNum= direction.ordinal()+ ICONNUM.WALK.ordinal()* 4;
                                break;
                            case 0:
                                iconNum= direction.ordinal()+ ICONNUM.WALK2.ordinal()* 4;
                                break;
                        }
                        break; 
                    } else {
                        this.action= ACTION.STAND;
                    }
                case STAND:
                case CUT:
                    iconNum= direction.ordinal()+ ICONNUM.STAND.ordinal()* 4;
                    break;
                
                case PUNCH:
                    if(0 == step) {
                        iconNum= direction.ordinal()+ ICONNUM.PUNCH.ordinal()* 4;
                    } else if(1 == step) {
                        iconNum= direction.ordinal()+ ICONNUM.DUKES.ordinal()* 4;
                    } else {
                        this.action= ACTION.STAND;
                    }
                    break;
                case FLIP:
                   if(0 == step) {
                        iconNum= direction.ordinal()+ ICONNUM.FLIP.ordinal()* 4;
                    } else if(1 == step) {
                        iconNum= direction.ordinal()+ ICONNUM.DUKES.ordinal()* 4;
                    } else {
                        this.action= ACTION.STAND;
                    }
                    break;
                case JUMP:
                    if(step < 2) {
                        iconNum= direction.ordinal()+ ICONNUM.JUMP.ordinal()* 4;
                    } else if(2 == step) {
                        iconNum= direction.ordinal()+ ICONNUM.DUKES.ordinal()* 4;
                    } else {
                        this.action= ACTION.STAND;
                    }
                    break;
                case DIE:
                    if(step < 5) {
                        iconNum= DEADICONNUM;
                    } else {
                        kill();
                    }
                    break;
                //default:
                    //break;
            }
            
            /*iconNum= direction.ordinal();
            int iconAction= 0;

            switch(action) {
                case STAND:
                case WALKLL:
                case WALKRL:
                    iconAction= ICONNUM.STAND.ordinal();
                    break;
                case WALKL:
                    iconAction= ICONNUM.WALK.ordinal();
                    break;
                case WALKR:
                    iconAction= ICONNUM.WALK2.ordinal();
                    break;
                case PUNCH:
                    iconAction= ICONNUM.PUNCH.ordinal();
                    break;
                case POSTPUNCH:
                    iconAction= ICONNUM.PUNCH2.ordinal();
                    break;
               case FLIP:
                    iconAction= ICONNUM.FLIP.ordinal();
                    break;
               case JUMP:
               case JUMP2:
                    iconAction= ICONNUM.JUMP.ordinal();
                    break;
               case DEAD:
                    iconAction= 0;
                    iconNum= 28;
                    break;
            }

            //iconNum+= iconAction*4;
            
            //this.iconNum= (this.iconNum+ 1) % 27; */
            icon= icons.get(iconNum);
        }

         /**
          * sets where the user wants to go, so that user doesn't go opposite directions.
          * @param direction which way the user wants to go.
          **/
         void setFutureDirection(DIRECTION direction) {
            futureDirection= direction;
         }

         /**
          * logical move after move.
          **
         void nextStep() {
            switch(action) 
            {
                case POSTPUNCH:
                case JUMP2:
                case FLIP:
                    action= ACTION.STAND;
                    action= ACTION.STAND;
                    break;
                case PUNCH:
                    action= ACTION.POSTPUNCH;
                    action= ACTION.STAND;
                    break;
                case JUMP:
                    action= ACTION.JUMP2;
                    break;
                default:    //DEAD, OUTFOREVER
                    break;
                case STAND:
               case WALKRL:
               case WALKL:
               case WALKLL:
               case WALKR:
                     if( !futureDirection.equals(DIRECTION.NONE)) {
                        switch(action) {
                            case STAND:
                            case WALKRL:
                                action= WALK;
                                break;
                            case WALKL:
                                action= ACTION.WALKLL;
                                break;
                            case WALKLL:
                                action= ACTION.WALKR;
                                break;
                            case WALKR:
                                action= ACTION.WALKRL;
                                break;
                        }
                    } else {
                        action= ACTION.STAND;
                        action= ACTION.STAND;
                    }

                    break;
            }

        }*/


         /**
          * Sets what the user wants to do, so that user doens't do two things at once.
          * @param action what the user wants to do.
          **/
         void setFutureAction(ACTION action) {
            futureAction= action;
         }

         /**
          * Sets the action the player will take.
          * @param action the action the player will take.
          **/
         void setAction(final ACTION action) {
           final Point current_Location= (Point)this.place.clone();
           final ACTION oldVerb= this.action;

           boolean changeAction= true;
           if(!canChange() && (
                (step < 3 && this.action.equals(ACTION.JUMP)) ||
                (step < 2 && this.action.equals(ACTION.FLIP))) )
            {
                nextStep();
            } else if( canChange() && (!futureAction.equals(ACTION.NONE) || pushed) ) //(action) >= ACTION.JUMP2 || (action) == ACTION.APRES
            {
                switch(action)
                {
                    case NONE: //walk
                    case STAND:
                    case WALK:
                        if(pushed) {
                            this.action= ACTION.WALK;

                            switch(this.direction) {
                                case LEFT:
                                    place.translate(-this.speed.width, 0);
                                    break;
                                case RIGHT:
                                    place.translate(this.speed.width, 0);
                                    break;
                                case UP:
                                    //place.setLocation(place.x, place.y-PVSPEED);
                                    place.translate(0, -this.speed.height);
                                    break;
                                case DOWN:
                                    place.translate(0, this.speed.height);
                                //default: //NONE
                                    break;
                            }
                        }
                        else {
                            this.action= ACTION.STAND;
                        }
                        break;
                    case PUNCH:
                            //doSound(PUNCHSOUND);
                            //action= ACTION.PUNCH;
                            tack= true;
                            this.action= ACTION.PUNCH;

                            switch(direction)
                            {
                            case UP:
                                    killZone.setBounds(
                                        place.x- this.speed.width*3/2,
                                        place.y- PPUADD,
                                        place.x+ this.speed.width*3/2,
                                        place.y+ IconNum.V_HUMAN/2);
                                    break;
                            case DOWN:
                                    killZone.setBounds(
                                        place.x- this.speed.width*3/2,
                                        place.y,
                                        place.x+ this.speed.width*3/2,
                                        place.y+ size.height+ PPDADD);
                                    break;
                            case RIGHT:
                                    /*killZone.setBounds(
                                        place.x,
                                        place.y- this.speed.height*3/2,
                                        place.x+ WIDTH+ PPRADD+ 10,
                                        place.y+ this.speed.height*3/2);
                                    */break;
                            case LEFT:
                                    moveOffsetX= -14;
                                    killZone.setBounds(
                                            place.x- PPLADD- 14,
                                            place.y- this.speed.height*3/2,
                                            place.x+ size.width- 14,
                                            place.y+ this.speed.height*3/2);
                                    break;
                            //default:	//error
                                    //break;
                            }/*switch(direction)*/
                        break;//out of switch(action)
                    case FLIP:
                        //doSound(FLIPSOUND);
                        //action= ACTION.FLIP;
                        tack= true;
                        this.action= ACTION.FLIP;

                        switch(direction)
                                {
                                case UP:
                                        killZone.setBounds(
                                            place.x+ this.speed.width*3/2- size.width,
                                            (place.x)- this.speed.width*3/2,
                                            (place.y)+ (IconNum.V_HUMAN/2),
                                            (place.y)+ size.height);//InOffSetRect(&(place), HFV, VFV, 0, -VFHEIGHT);
  
                                        place.translate(0, -V_FLIP_DISTANCE);
                                            moveOffsetY= -V_FLIP_DISTANCE;
                                        /*if(checkWall(this)) {
                                            //doSound(HITSIDESOUND);
                                            moveOffsetY= 0;
                                        }*/
                                        break;
                                case DOWN:
                                        killZone.setBounds(
                                            (place.x)+ this.speed.width*3/2-size.width,
                                            (place.x)- this.speed.width*3/2,
                                            (place.y)- (IconNum.V_HUMAN/2),
                                            (place.y)- (IconNum.V_HUMAN/2)-size.height);//InOffSetRect(&(place), HFV, VFV, 0, -VFHEIGHT);
                                        
                                        place.translate(0, V_FLIP_DISTANCE);
                                        moveOffsetY= V_FLIP_DISTANCE;
                                       /* if(checkWall(this)) {
                                            moveOffsetY= 0;
                                            //doSound(HITSIDESOUND);
                                        }*/
                                        break;
                                case RIGHT:
                                        /*killZone.setBounds(
                                            place.x,
                                            place.y,
                                            WIDTH,
                                            HEIGHT);//InOffSetRect(&(place), HFH, VFH, 0, -HFHEIGHT);
                                        */
                                        place.translate(H_FLIP_DISTANCE, 0);
                                        moveOffsetX= H_FLIP_DISTANCE;
                                       /* if(checkWall(this)) {
                                            moveOffsetX= 0;
                                            //doSound(HITSIDESOUND);
                                        }*/
                                        break;
                                case LEFT:
                                        killZone.setBounds(
                                            place.x,
                                            place.y,
                                            size.width,
                                            size.height);//InOffSetRect(&(place), HFH, VFH, 0, -HFHEIGHT);

                                        place.translate(-H_FLIP_DISTANCE, 0);
                                        moveOffsetX= -H_FLIP_DISTANCE;
                                       /* if(checkWall(this)) {
                                            moveOffsetX= 0;
                                            //doSound(HITSIDESOUND);
                                        }*/
                                         break;
                                //default: //error
                                        //break;
                                }/*switch(dir)*/
                        break;//out of switch(action)
                    case JUMP:
                        if(0 == jumps) {
                            //doSound(JUMP_EMPTY_SOUND);
                            break;
                        }
                        jumps--;
                        //action= ACTION.JUMP;
                        this.action= ACTION.JUMP;
                        tack= true;

                        switch(direction)
                                {
                                case UP:
                                        killZone.setBounds(
                                            place.x,
                                            place.y,
                                            size.width,
                                            size.height);//InOffSetRect(&(place), HFH, VFH, 0, -HFHEIGHT);

                                        place.translate(0, -V_JUMP_DISTANCE);
                                        moveOffsetY= -V_JUMP_DISTANCE;
                                        /*if(checkWall(this))
                                        {
                                            moveOffsetY= 0;
                                            //doSound(HITSIDESOUND);
                                        }*/
                                         break;
                                case DOWN:
                                        killZone.setBounds(
                                            place.x,
                                            place.y,
                                            size.width,
                                            size.height);//InOffSetRect(&(place), HFH, VFH, 0, -HFHEIGHT);
                                        place.translate(0, V_JUMP_DISTANCE);
                                        moveOffsetY= V_JUMP_DISTANCE;
                                        /*if(checkWall(this))
                                        {
                                            moveOffsetY= 0;
                                            //doSound(HITSIDESOUND);
                                        }*/
                                        break;
                                case RIGHT:
                                        killZone.setBounds(
                                            place.x,
                                            place.y,
                                            size.width,
                                            size.height);//InOffSetRect(&(place), HFH, VFH, 0, -HFHEIGHT);

                                        place.translate(H_JUMP_DISTANCE, 0);
                                        moveOffsetX= H_JUMP_DISTANCE;
                                        /*if(checkWall(this))
                                        {
                                            moveOffsetX= 0;
                                            //doSound(HITSIDESOUND);
                                        }*/
                                        break;
                                case LEFT:
                                        killZone.setBounds(
                                            place.x,
                                            place.y,
                                            size.width,
                                            size.height);//InOffSetRect(&(place), HFH, VFH, 0, -HFHEIGHT);

                                        place.translate(-H_JUMP_DISTANCE, 0);
                                        moveOffsetX= -H_JUMP_DISTANCE;
                                        /*if(checkWall(this))
                                        {
                                            moveOffsetX= 0;
                                            //doSound(HITSIDESOUND);
                                        }*/
                                        break;
                                //default:
                                        //break;
                                }/*switch*/
                        break;//out of switch(action)
                    default:    //error
                        break;//out of switch(action)
                }
            } else {
//                nextStep();
//                setIcon();
            }

            this.tack= this.tack || !this.action.equals(oldVerb);

            //check that a wall hasn't been run into
            if(checkWall()) {
                //doSound(HIT_WALL_SOUND);
                System.out.println("Hit Wall");
                //try to get closer to the wall
                final Point closer= (Point)current_Location.clone();
                closer.translate((this.place.x- current_Location.x)/2, (this.place.y- current_Location.y)/2);
                if(this.game.view.gameBoard.barriers.contains(closer)) {
                    this.place= current_Location;
                } else {
                    this.place= closer;
                }
            }
        }

}

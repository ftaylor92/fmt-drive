package hero.persistent;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.io.File;
import java.io.Serializable;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JDialog;
import javax.swing.JTable;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.table.TableModel;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.Box;
import javax.swing.BoxLayout;

import hero.Util;
/**
 * To display and save High Scores
 * @author  TaylorFM
 */
public class HighScores {
    static final int TOTAL_SCORES= 10;
    private JDialog scoreDlg= null;
    private final List<Score> scores= new ArrayList<Score>(10);
    private final File scoreFile= new File("scores.txt");
    private final JFrame parent;
    JTable jt;

    /** Creates a new instance of HighScores */
    public HighScores(JFrame parent) {
        this.parent= parent;

        //getHighscores();
    }

    public void getHighscores() {
        scores.clear();
         FileInputStream fIn= null;
        ObjectInputStream oIn= null;
            try {
                fIn= new FileInputStream(scoreFile);
                oIn= new ObjectInputStream(fIn);
             } catch (FileNotFoundException ex) {
                System.out.println(ex);
            } catch(IOException ex) {
                System.out.println(ex);
            }

               while(true) {
                 try {
                      Score sIn= (Score)oIn.readObject();
                       scores.add(sIn);
                   } catch(ClassNotFoundException ex) {
                        break;
                    } catch(IOException ex) {
                        break;
                    }
               }

               try {
                    oIn.close();
                } catch(IOException ex) {
                    System.out.println(ex);
                }
         Collections.sort(scores);
    }

    public void addHighScore(String name, int level, int score) {
        scores.add(new Score(name, level, score));

        Collections.sort(scores);
        if(scores.size() > TOTAL_SCORES) {
            scores.remove(TOTAL_SCORES);
        }
    }

    public Object[][] asArray() {
        String[][] sArray= new String[10][3];
        int i= 0;
        for(Score s : scores) {
            sArray[i++]= new String[] {s.name, Integer.toString(s.level), Integer.toString(s.score)};
        }

        return sArray;
    }

    public void displayScores() {
        scoreDlg= new JDialog(parent, "High Scores", false);

       //scoreDlg.addWindowListener(new BasicWindowMonitor());
       /*TableModel dataModel = new AbstractTableModel() {
          public int getColumnCount() { return 3; }
          public int getRowCount() { return 10;}
          public Object getValueAt(int row, int col) { return scores.get(row); }
      };*/
      //JTable table = new JTable(dataModel);
       jt= new JTable(this.asArray(), new String[] {"Name","Level","Score"});
       jt.setColumnSelectionAllowed(false);
       jt.setRowSelectionAllowed(false);
       jt.setCellSelectionEnabled(false);
        //make table non-editable jt.setSelectionMode(0);
       jt.setSize(100, 100);
       JScrollPane jsp= new JScrollPane(jt);
       jsp.setSize(100,100);
       scoreDlg.add(jsp, BorderLayout.NORTH);

       JPanel bp= new JPanel(); //Box.createHorizontalBox();
       JButton close= new JButton("OK");
       JButton clear= new JButton("clear Highscores");
        clear.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clearScores();
            }
        });
        close.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                HighScores.this.scoreDlg.dispose();
                HighScores.this.scoreDlg= null;
            }
        });
       bp.add(clear, BorderLayout.WEST);
       bp.add(close, BorderLayout.EAST);
       scoreDlg.getRootPane().setDefaultButton(close);

       scoreDlg.add(bp, BorderLayout.SOUTH);

       scoreDlg.pack();
       scoreDlg.setLocation(Util.getCenteredLocation(parent.getBounds(), scoreDlg.getBounds()));
       
       //scoreDlg.setSize(200, 160);


       //scoreDlg.setDefaultCloseOperation(JDialog.EXIT_ON_CLOSE);
       scoreDlg.setVisible(true);
    }

    public void saveHighscores() {
        FileOutputStream fOut= null;

            try {
                fOut= new FileOutputStream(scoreFile, false);
             } catch (FileNotFoundException ex) {
                System.out.println(ex);
            }

            try {

               ObjectOutputStream oOut= new ObjectOutputStream(fOut);

                for(Score s : scores) {
                    oOut.writeObject(s);
                    //s.writeObject(oOut);
                }

                oOut.flush();
                oOut.close();
            } catch(IOException ex) {
                System.out.println(ex);
            }
     }

    public boolean isHighScore(int level, int score) {
        Score newScore= new Score("Unk", level, score);

        int lowerThan= 0;
        for(Score aScore : scores) {
            if( newScore.compareTo(aScore) < 0) {
                lowerThan++;
            }
        }

        return (lowerThan != 10);
    }

    public void clearScores() {
        System.out.printf("%d scrores deleted.\n", scores.size());
        scoreFile.delete();
        scores.clear();
        jt.removeAll();
        jt.repaint();
    }


}

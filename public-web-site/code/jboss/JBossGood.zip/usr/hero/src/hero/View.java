package hero;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.Dimension;
import javax.swing.BorderFactory;
import javax.swing.JWindow;
import javax.swing.JComponent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JCheckBoxMenuItem;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.Box;
import javax.swing.BoxLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyAdapter;
import java.awt.Toolkit;
import java.awt.Image;
import javax.swing.ImageIcon;
import java.awt.Graphics;
import javax.swing.KeyStroke;
import java.applet.Applet;
import javax.swing.JApplet;

import hero.ScreenItem.DIRECTION;


/**
 * represents the View the user sees, not Model or Control.
 * May be a JApplet in the future.
 *	@author	ftaylor
 */
public class View	{
         //public JApplet	wFrame;  //Swing main app-frame

    /**Application that this shows**/
	 public final ChineseHero application;
	 Board gameBoard;
         public JFrame	frame;  //Swing main app-frame
         public JPanel content; //content where everything is drawn.
	 static String	labelPrefix	= "Number of button clicks: ";
	 static int	numClicks =	0;
	 //Board	gameBoard;

       //Swing
        private final JMenuBar menuBar= new JMenuBar();
        private final JMenu GameMenu= new JMenu("Game");
        private JMenuItem newGame, open, quit, changePrefs, about, showScores;    //menu items that never need to be accessed
        /**menu items, for dimming and activating**/
        public JMenuItem end, save;
        public JCheckBoxMenuItem pause;
	 
	 /**
	  * Sets up the Java/Swing parts of the View.
	  * JFrame, KeyListener, etc.
          * @param gameName title for main window
          * @param size how large to make the main window.
	  **/
	 public void createDisplay(String gameName, Dimension size) {
		  this.frame	= new	JFrame( gameName );
		  this.content= (JPanel)this.frame.getContentPane();
                  //add board was here
		  
                  setupMenus(frame);

		  frame.pack();
		  frame.setSize(size);
                  // splashScreen(this.content);
                  //frame.repaint();
                  frame.setVisible(true);

                 this.frame.addKeyListener(new PlayerListener());
                 this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                 this.frame.getRootPane().getInputMap().put(KeyStroke.getKeyStroke("typed w"), "walk");

                this.frame.getRootPane().getActionMap().put("walk",
                        new AbstractAction("walk") {
                            public void actionPerformed(ActionEvent evt) {
                                System.out.println("WALK");
                            }
                        }
                    );
	 }

     	 /**
	  * Sets up the Java/Swing parts of the View.
	  * JFrame, KeyListener, etc.
          * @param gameName title for main window
          * @param size how large to make the main window.
	  
	 public void createWebDisplay(String gameName, Dimension size) {
		  this.frame	= new	JFrame( gameName );
//                  this.wFrame= new JApplet(gameName);
		  this.content= (JPanel)this.wFrame.getContentPane();
                  //add board was here
		  
                  setupMenus(frame);

		  frame.pack();
		  frame.setSize(size);
                  splashScreen();
                  //frame.repaint();
                  frame.setVisible(true);

                 this.frame.addKeyListener(new PlayerListener());
                 this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                 this.frame.getRootPane().getInputMap().put(KeyStroke.getKeyStroke("typed w"), "walk");

                this.frame.getRootPane().getActionMap().put("walk",
                        new AbstractAction("walk") {
                            public void actionPerformed(ActionEvent evt) {
                                System.out.println("WALK");
                            }
                        }
                    );
	 }
         **/
         
	 /**
	  * Overrides super.repaint().
	  * repaints the screen for each "loop".
	  **/
	 public void refresh() {
            //menubar & swing.refresh
            if(null != gameBoard) {
                gameBoard.repaint();
            }   
            frame.repaint();
	 }
	 
	 /** Creates a	new instance of View	
	  * sets up background image for each level's screen.
          * @param application Application this View is associated with.
	  **/
	 public View(ChineseHero application)	{
		  this.application= application;

		  createDisplay("Chinese Hero", new Dimension(768, 512));
	 }
	 
	 /**
	  * Controller: listens for keys from user.
	  * overrides KeyListener.
          * see: JComponent.getInputMap()
	  **/
	 public class PlayerListener implements KeyListener
	 {
		  public	void keyPressed(KeyEvent e) {
                                //System.out.println("press "+ e.getKeyCode());
				for(int i=0; i	< application.game.players.size(); i++) {
                                         if(!View.this.application.game.level.mode.equals(Level.MODE.CONTINUE)) {
                                             View.this.application.game.level.interrupt();
                                         }
                                         /*if(View.this.application.game.isPaused()) {
                                             View.this.application.game.pause(false);
                                         }*/
                                         
					 Player man= application.game.players.get(i);
					 DIRECTION dir= man.directionKeys.get(e.getKeyCode());
					 if( null != dir ) {
						  man.setFutureDirection(dir);
					 }/* else {
                                            System.out.printf("No Key %c\n", e.getKeyCode());
                                         }*/
                                         Human.ACTION act= man.actionKeys.get(e.getKeyCode());
                                         if( null != act ) {
						  man.setFutureAction(act);
					 }  
				}
		  }

		  public	void keyReleased(KeyEvent e) { 
                                //System.out.println("release "+ e.getKeyCode());
                  		for(int i=0; i	< application.game.players.size(); i++) {
					 Player man= application.game.players.get(i);
					 DIRECTION dir= man.directionKeys.get(e.getKeyCode());
					 if( null != dir ) {
                                                  if(dir.equals(man.futureDirection) || man.futureDirection.equals(man.direction))
						     man.setFutureDirection(DIRECTION.NONE);
					 }/* else {
                                            System.out.printf("No Key %c\n", e.getKeyCode());
                                         }
                                         Human.ACTION act= man.actionKeys.get(e.getKeyCode());
                                         if( null != act ) {
						  man.setFutureAction(act);
					 }  */
				}
                }
		  public	void keyTyped(KeyEvent e) {
                        //System.out.println("typed "+ e.getKeyCode());
                 }	
	 }

        /**
         * Sets up all menus.
         * @param frame window for which to set up menus.
         **/
        public void setupMenus(final JFrame frame) {
            //Menus
            //Save, Open, change Prefs, Quit, Pause, New Game
            //pause menu item is greyed out
            GameMenu.setMnemonic(KeyEvent.VK_N);
            GameMenu.setMnemonic(KeyEvent.VK_G);
            newGame= new JMenuItem("New...");
            newGame.setMnemonic(KeyEvent.VK_N);
            newGame.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    closeSplash(true);
                    //new game dialog with players#, names, and which level to start at
                }
            });

            pause= new JCheckBoxMenuItem("Pause");
            pause.setMnemonic(KeyEvent.VK_P);
            pause.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    View.this.application.game.pause(!View.this.application.game.paused);
                }
            });


            open= new JMenuItem("Open...");
            open.setMnemonic(KeyEvent.VK_O);
            open.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    application.openGame();
                }
            });

            save= new JMenuItem("Save...");
             save.setMnemonic(KeyEvent.VK_S);
           save.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    application.saveGame();
                }
            });
            
            end= new JMenuItem("End");
             end.setMnemonic(KeyEvent.VK_E);
           end.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    //do pre-Quit stuff
                    View.this.application.game.end();
                }
            });

            changePrefs= new JMenuItem("Options...");
             changePrefs.setMnemonic(KeyEvent.VK_K);
           changePrefs.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    View.this.application.game.changeKeys();
                }
            });

            about= new JMenuItem("Info...");
             about.setMnemonic(KeyEvent.VK_I);
           about.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    information();
                }
            });

            showScores= new JMenuItem("High Scores...");
             showScores.setMnemonic(KeyEvent.VK_H);
           showScores.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    application.highScores.displayScores();
                }
            });

            quit= new JMenuItem("Quit");
             quit.setMnemonic(KeyEvent.VK_Q);
           quit.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    //do pre-Quit stuff
                    View.this.application.quit();
                }
            });

            GameMenu.add(newGame);
            GameMenu.add(pause);
            pause.setEnabled(false);
            GameMenu.addSeparator();
            GameMenu.add(open);
            GameMenu.add(save);
            save.setEnabled(false);
            GameMenu.add(end);
            end.setEnabled(false);
            GameMenu.addSeparator();
            GameMenu.add(changePrefs);
            GameMenu.add(about);
            GameMenu.add(showScores);
            GameMenu.addSeparator();
            GameMenu.add(quit);

            menuBar.add(GameMenu);
            frame.setJMenuBar(menuBar);
        }

       /*public void startNewGame() {
            System.out.println("25 cents");


            application.newGame();
        }*/

        /**
         * adds the game board to the view, where the view is like the controler and the board is like the view.
         **/
        public void addBoard() {
            int x= 768;
            int y= 512;

            gameBoard= new Board(this);
            this.frame.add(gameBoard/*, BorderLayout.CENTER*/);

            gameBoard.setSize(x,y);
            //frame.pack();
            frame.setSize(x,y);

            //afterStart()
            save.setEnabled(true);
            end.setEnabled(false);
            pause.setEnabled(true);

            this.frame.requestFocus();           
        }

        /**
         * closes all things happening in the main window, then starts a game, if requested.
         * @param startGame whether to start a new game, otherwise just leave the window blank.
         **/
        public void closeSplash(boolean startGame) {
            frame.getContentPane().removeAll();  //.getContentPane()
            refresh();

            if(startGame) {
                application.newGame();
            }
         }

         /**
          * starts displaying the initial "Splash" screen.
          **/
         public static void splashScreen(Container content, Applet webApp) {
            //splashFrame= new JWindow();

            JButton startGame= new JButton("Start Game");
            startGame.addActionListener( new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    //closeSplash(true);
                }
            });
            JButton cancel= new JButton("Cancel");
            cancel.addActionListener( new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    //closeSplash(false);
                }
            });


            Box left= Box.createVerticalBox();
            Box middle= Box.createVerticalBox();
            //middle.setLayout(new BoxLayout(splashFrame,BoxLayout.Y_AXIS));
            Box right= Box.createVerticalBox();
            //right.setLayout(new BoxLayout(splashFrame,BoxLayout.Y_AXIS));

            /*left.add(new JLabel(new ImageIcon("images/windows/splash_ninja.jpg")));
            middle.add(new JLabel(new ImageIcon("images/windows/splash_title.jpg")));
            middle.add(new JLabel(new ImageIcon("images/windows/splash_author.jpg")));
            right.add(new JLabel(new ImageIcon("images/windows/splash_company.jpg")));*/
            ImageIcon aPicture= Util.loadImage("images/windows/splash_ninja.jpg", webApp);
            left.add(new JLabel(aPicture));
            //middle.add(new JLabel(new ImageIcon(Util.loadImage("images/windows/splash_title.jpg"))));
            //middle.add(new JLabel(new ImageIcon(Util.loadImage("images/windows/splash_author.jpg"))));
            //right.add(new JLabel(new ImageIcon(Util.loadImage("images/windows/splash_company.jpg"))));
            
            right.add(startGame);
       //     content.getRootPane().setDefaultButton(startGame);
            //right.add(cancel);

            content.setLayout(new FlowLayout());
            content.setBackground(Color.WHITE);
            content.add(left);
            content.add(middle);
            content.add(right);

            //splashFrame.pack();
            //splashFrame.setVisible(true);
         }

         /**
          * displays the Info screen on the main window.
          **/
         public void information() {
            //final JWindow infoFrame= new JWindow(this.frame);
            final JPanel content= (JPanel)this.frame.getContentPane();//(JPanel)infoFrame.getContentPane();
            content.removeAll();

            final JButton picture= new JButton(new ImageIcon("images/windows/about1.jpg"));
 
            content.add(picture);

            //content.invalidate();
            refresh();

            //infoFrame.setBounds(20,20,400,300);
            //infoFrame.pack();
            //infoFrame.setVisible(true);

            picture.addActionListener( new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    //content.removeAll();
                    String image= "images/windows/about2.jpg";

                    switch(++numClicks) {
                        /*case 1:
                            image= "images/windows/about2.jpg";
                            break;*/
                        case 2:
                            image= "images/windows/order1.jpg";
                            break;
                        case 3:
                            image= "images/windows/order2.jpg";
                            break;
                        case 4:
                            numClicks= 0;
                            closeSplash(false);
                            return;
                    }
                    picture.setIcon(new ImageIcon(image));
                    //content.add(new JButton(new ImageIcon("images/windows/about2.jpg")));
                    refresh();
                }
            });
         }
}

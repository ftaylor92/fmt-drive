package hero;

import java.io.Serializable;
import java.awt.Point;
import java.awt.Font;
import java.awt.Graphics2D;
import hero.ScreenItem.DIRECTION;
/**
 * represents one level of a game.
 * @author  TaylorFM
 */
public class Level implements Serializable {
    /** Game this Level is a part of.**/
    final public Game game;
    /**How many of each type of enemy is in each level**/
    public int ninja_count, archer_count, swordsmen_count;
    /**which level is this**/
    static public int level_num= 0;
    /**How much more earth-quaking will occur**/
    public int earthquake= 0;
    /**where is movies/multi-part displays are we**/
    private int movie_step;
    /**Parts of a Level: CONTINUE==just playing, starting with a display, or Game Over, etc.**/
    public static enum MODE { CONTINUE, NEWGAME, OPENGAME, QUITAPP, STARTWARLORD, STARTBONUS, LEVELOVER, GAMEOVER, PAUSEGAME, CONTINUEGAME, STARTLEVEL, CAPTURE, CASTLE, RELEASE, CHASE }
    /**in what part of the Level are we.  CONTINUE==just playing**/
    MODE mode;
    private int movie_scene= 0;
    
    /** 
      * Creates a new instance of Level.
      * @param game Game of which this level is part.
     **/
    public Level(Game game) {
        this.game= game;
        
        mode= MODE.NEWGAME;
    }
    
    public int getEnemyCount() {
        return ninja_count+archer_count+swordsmen_count;
    }

    /**
     * returns if level should be over.
     * @return whether this level is over (i.e. no more battles to be fought).
     **/
    public boolean isLevelOver() {

        if(game.enemies.size() == 0 && getEnemyCount() == 0) return true;
        if(arePlayersDead())    return true;
        
        return false;
    }

    /**
     * Clears away dead enemies from list.
     **/
    public void cleanEnemies() {
        for(Enemy enemy : game.enemies) {
            if(!enemy.alive) {
                game.enemies.remove(enemy);
                cleanEnemies(); //recursion!
                break;
            }
        }
    }

    /**
     * @return if all Players are dead.
     **/
    public boolean arePlayersDead() {
        for(Player man : game.players) {
            if(man.alive)   return false;
        }

        return true;
    }
    
    public void interrupt() {
        switch(mode) {
            case CONTINUE:
                break;
            case STARTLEVEL:
                movie_step= 1;
                break;
            default:
                this.mode= MODE.STARTLEVEL;
                movie_step= 16;
                break;
        }
    }
    
    /**
     * Displays for Movies/Multi-part marches/messages, etc.
     * @param screen on what to draw.
     * @return 
     */
    boolean movie(Graphics2D screen) {
        if(mode.equals(MODE.CONTINUE))  return true;
        boolean showPlayers= true;
        
        switch(this.mode) {
            case CONTINUE:
                return true;
                //break;
            case STARTLEVEL:
                 if(0 == movie_step--) {
                    mode= MODE.CONTINUE;
                }
               final String levelStr= Util.strRes.getProperty("LEVEL","Level");
                final Font oldFont= this.game.view.gameBoard.getFont();
                this.game.view.gameBoard.setFont(oldFont);
                //this.game.view.gameBoard.setFont(new Font("Courier", Font.ITALIC, 48));
                //monaco bold italic outline 48 point
                this.game.view.gameBoard.showCenteredText(screen, levelStr+" "+ level_num);

                this.game.view.gameBoard.setFont(oldFont);
                
                //Oval gets smaller behind text
                break;
            case CAPTURE: {
                showPlayers= false;
                switch(movie_scene) {
                    case 0:
                        //this.game.pause(true);
                        Enemy escort= new Enemy(this.game, new Point(0, this.game.view.content.getHeight()/2), Enemy.POINTS.NINJASCORE, "Green", true);
                        //this.game.enemies.add(escort);
                        this.ninja_count--;
                        escort= new Enemy(this.game, new Point(50, this.game.view.content.getHeight()/2), Enemy.POINTS.NINJASCORE, "Green", true);
                        //this.game.enemies.add(escort);
                        this.ninja_count--;

                        Enemy princess= new Enemy(this.game, new Point(25, this.game.view.content.getHeight()/2), Enemy.POINTS.NINJASCORE, "Green", false);
                        //this.game.enemies.add(0, princess);
                        movie_scene++;
                        break;
                    case 1:
                        int center= this.game.view.content.getWidth()/2;
                        if(this.game.enemies.size() > 0 && this.game.enemies.get(0).place.x > center) movie_scene++;    //fix
                        
                        for(Human piece : this.game.enemies) {
                            piece.setFutureDirection(Human.DIRECTION.RIGHT);
                        }
                        break;
                    case 2:
                        if(this.game.enemies.get(0).place.y < 120) {
                            for(Human piece : this.game.enemies) {
                                piece.setFutureDirection(Human.DIRECTION.DOWN);
                                piece.setFutureAction(Human.ACTION.STAND);
                            }
                            movie_scene++;
                        }
                        movie_step= 0;
                        for(Human piece : this.game.enemies) {
                            piece.setFutureDirection(Human.DIRECTION.UP);
                        }
                        //this.game.pause(false);
                        break;
                    case 3:
                        for(Human piece : this.game.enemies) {
                            piece.setFutureDirection(Human.DIRECTION.NONE);
                            piece.direction= Human.DIRECTION.DOWN;
                            piece.setFutureAction(Human.ACTION.STAND);
                        }
                        if(movie_step++ == 7) {
                            movie_scene++;
                            movie_step=0;
                        }
                        break;
                    case 4:
                        if(movie_step++ == 20) {
                            mode= MODE.STARTLEVEL;
                        }
                        break;
                }
                } break;
            /*if(Continue < GAMEOVER)
            {
            if((level%10) == 0)
                    {
    warlordLevelStart:
                    Continue= CONTINUE;
                    doMovie(CASTLE);
                    WarlordLevel(&first, clock);
                    }
            else if((level%5) == 0)
                    {
    bonusLevelStart:		
                    Continue= CONTINUE;
                    BonusLevel(&first, clock);
                    doMovie(CHASE);
                    }
            }*/
            default:
                return false;
                //break;
        }
        return true;    //showPlayers;
    }
    
    /**
     * called when new level begins to ensure that the level starts off with proper displays.
     **/
    void levelPrelude()
    {
        //this.game.pause(true);
        this.mode= MODE.STARTLEVEL;
        movie_step= 16;
        
        this.nextLevel();
        
        this.game.view.gameBoard.createBackground();
        
        this.setPlayersStartPlace();
        
        //this.mode= MODE.CONTINUE;
        //this.game.pause(false);
        //ObscureCursor();
    }
    
    /**
     * Cleanup last level and prepare for next level.
     **/
    public void nextLevel() {
       level_num++;
       switch(level_num%11) {
           case 1:
               mode= MODE.CAPTURE;
               break;
           case 2:
               mode= MODE.STARTLEVEL;
               break;
           case 3:
               mode= MODE.CHASE;
               break;
           case 4:
               mode= MODE.CASTLE;
               break;
           case 5:
               mode= MODE.STARTBONUS;
               break;
           case 10:
               mode= MODE.RELEASE;
               break;
       }

        /*ninja_count= level_num* 3;
        archer_count= level_num- 1;
        swordsmen_count= level_num- 1;*/
        //enemy_count= ninja_count+ archer_count+ swordsmen_count;
        
        ninja_count= ((level_num-1) *3)+ 4;					//Number of Enemies per level;
        archer_count= (level_num < 3) ? 0 : (level_num- 2);	//Number of Archers in level
        swordsmen_count= (level_num < 4) ? 0 : (level_num- 3);	//Number of Swordsmen in level

        ninja_count= archer_count= swordsmen_count= 0; //debug
        ninja_count= 3;
        archer_count= 1;
        //make background
        //water
        //barriers
        //ports
    }
    
    /**
     * sets up the player piees correctly for the beginning of next level of fighting
     **/
    void setPlayersStartPlace() {
        int line= (int)this.game.view.content.getBounds().getHeight()/2;
        int right_side= (int)this.game.view.content.getBounds().getWidth()- 50;
        int left_side= 50;
        
        boolean left= true;
        for(Player man : this.game.players) {
            if(!man.outForever) {
                if(left) {
                    line+= man.size.height;
                    man.place.setLocation(left_side, line);
                    man.reset(DIRECTION.RIGHT, Player.resetType.RESETLEVEL);
                } else {
                    man.place.setLocation(right_side, line);
                    man.reset(DIRECTION.LEFT, Player.resetType.RESETLEVEL);
                }
                left= !left;
            }
        }
    }
}

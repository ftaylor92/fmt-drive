package hero;

import java.awt.Point;
import java.awt.Image;
import java.awt.Graphics2D;
import java.util.Collection;
import java.util.List;
import java.util.Arrays;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

/**
 * Represents Swordsman Enemy person.
 * @author  TaylorFM
 */
public class Swordsman extends Enemy {

    /** Creates a new instance of Swordsman */
    public Swordsman(Game game, Point location) {
        super(game, location, POINTS.SAMURAISCORE, "Samurai", false);
    }
    
    void setAction(final ACTION action) {
        if(action.equals(ACTION.CUT)) {
            this.action= ACTION.CUT;
        } else {
            super.setAction(action);
        }
    }
    
    public ACTION getKillAction() {
        final int space= Math.abs(victim_location.x- this.place.x)+ Math.abs(victim_location.y- this.place.y);
        if(!reachable(victim_location).equals(ACTION.NONE)) {
            //BRANDISH SWORD
            //freezer= 6;
            return ACTION.CUT;
        } else {
            if(true)    return ACTION.CUT;  //debug
            if(Util.random.nextInt(2) == 0) {
                return ACTION.STAND;
            } else {
                return ACTION.WALK;
            }
        }
    }
    
      public void draw(Graphics2D screen) {
        super.draw(screen);
        
        screen.drawOval(place.x, place.y,size.width, size.height);
        screen.drawString(this.action.name(),place.x,place.y);
        screen.drawString(this.futureAction.name(),place.x,place.y+20);
        
        if(this.action.equals(ACTION.CUT)) {
            step++;
            if(step > 6)    this.action= ACTION.NONE;
            if(1 == step || 5 == step) {    //Sword tip only
                screen.drawImage(icons.get(DEADICONNUM+this.direction.ordinal()), this.place.x- this.ICON_LOCATION.x, this.place.y- this.ICON_LOCATION.y, null);
            }
            if( step > 1 && step < 5 ) {    //Sword extended
                screen.drawImage(icons.get(DEADICONNUM+this.direction.ordinal()), this.place.x- this.ICON_LOCATION.x, this.place.y- this.ICON_LOCATION.y, null);                
                screen.drawImage(icons.get(DEADICONNUM+this.direction.ordinal()+4), this.place.x- this.ICON_LOCATION.x, this.place.y- this.ICON_LOCATION.y, null);                
            }
        }
      }
      
      void setIcons(String type) throws IOException {
        this.icons= Enemy.swordsmen_icons;
      }
      
        /**
         * places a set of images, based on type, into a list.
         * @param icons list to place images into
         * @param type which folder under images/ to get images from.
         **/
        public static void addSwordIcons(final List<Image> icons) throws IOException {
            final String parentDir= "images/weapons/"; //C:/development/fava/hero/
           // Collection<String> sword_parts= {"TRIDENT","SHAFT"};
            String[] sword_parts= {"SHAFT","TRIDENT"};
            Collection<DIRECTION> dirs= Arrays.asList(DIRECTION.LEFT,DIRECTION.RIGHT,DIRECTION.UP,DIRECTION.DOWN); //directionKeys.values();
 
            int place= 0;
            for(String part : sword_parts ) {
                for(DIRECTION dir : dirs) {
                    String iconName= dir+"_"+ part;
                    try {
                        icons.add(ImageIO.read(new File(parentDir+iconName+".gif")));
                    } catch(IOException ex) {
                        System.out.println(ex);
                    }
                }
            }
        }
        
        public void nextStep() {
            super.nextStep();
        }
        
        public boolean canChange() {
            if(this.action.equals(ACTION.CUT)) {
                if(step < 8) {
                     return false;
                } else {
                    this.setFutureAction(ACTION.NONE);
                }
            } 
            
            return true;
        }

}

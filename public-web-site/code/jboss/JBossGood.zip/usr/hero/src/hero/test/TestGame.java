package hero.test;

import hero.Player;
import hero.Human;

import junit.framework.TestCase;

/**
 *
 * @author  TaylorFM
 */
public class TestGame extends TestCase{

    /** Creates a new instance of TestGame */
    public TestGame(String name) {
        super(name);
    }

    /**
     * tests Player step icon
     **/
    public void testSomething() {
        Player person= new Player("Mumsy");

        assertEquals(person.getDirection(), Human.DIRECTION.RIGHT);
    }

}

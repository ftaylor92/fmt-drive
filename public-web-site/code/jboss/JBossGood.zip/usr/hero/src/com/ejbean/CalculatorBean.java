package com.ejbean;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

public class CalculatorBean implements SessionBean {
	SessionContext ctx;
	int total= 0;

	public void ejbCreate() throws CreateException {
	}

	public void setSessionContext(SessionContext ctx) throws EJBException {
		this.ctx= ctx;
		   
	}

	public void ejbRemove() throws EJBException {
	}

	public void ejbActivate() throws EJBException {
	}

	public void ejbPassivate() throws EJBException {
	}

	public void addTo(int a) {
		System.out.println("From add to function!");
		total+= a;
	}

	public int getTotal() {
		System.out.println("Total function!");
		return total;
	}

	public int add(int a, int b) {
		System.out.println("From add function!");
		return a+b;
	}

	public int divide(int a, int b) {
		System.out.println("From division function!");
		return a/b;
	}

	public int multiply(int a, int b) {
		System.out.println("From multiply function!");
		return a*b;
	}
}
package com;

import java.sql.*;
import javax.sql.*;
import java.io.*;
import javax.naming.*;

public class DBQuery {

	public static String getName(int id) {
		String name= "marr"; //null
		try {
		/*Context initCtx = new InitialContext();
		Context envCtx = (Context) initCtx.lookup("java:comp/env");
		DataSource ds = (DataSource)envCtx.lookup("jdbc/MySqlDS");*/
		//Oreilly version
		InitialContext initialContext= new InitialContext();
		DataSource ds= (DataSource)initialContext.lookup("java:/MySqlDS");
		

		Connection conn = ds.getConnection();

		Statement s= conn.createStatement();

		ResultSet res= s.executeQuery("select name from customers where id=\'"+id+"\';");

		res.next();

		name= res.getString("name");
		

		conn.close();
		} catch(Exception ex) {
			name= ex.getMessage()+" erx";
		}

		return name;
	}

}
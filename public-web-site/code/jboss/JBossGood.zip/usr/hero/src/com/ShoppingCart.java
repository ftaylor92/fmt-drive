package com;

import java.util.*;
import java.io.Serializable;

/**
 * Shopping Cart JavaBean
 **/
public class ShoppingCart implements Serializable {
   private int accountNum;
   private Vector<Integer> items;

   public ShoppingCart() {
 	items= new Vector<Integer>();
   }

   public int getAccountNum() {
	return this.accountNum;
   }

   public void setAccountNum(int accountNum) {
	this.accountNum= accountNum;
   }

   public Iterator getItems() { return this.items.iterator(); }
   public boolean addItem(int item) {
	return items.add(new Integer(item));
   }

   public String toString() {
	return "ShoppingCart for "+ accountNum;
   }
}
package com.ejbean;

import java.util.*;
import javax.ejb.*;
import java.rmi.*;
/**
 *
 * @author ftaylor
 */
public interface CourseHome extends EJBLocalHome {
    Course findByPrimaryKey(java.lang.String name) throws FinderException/*,RemoteException*/;
    public Collection findByInstructor(java.lang.String instructor) throws FinderException;
    public Collection findAll() throws FinderException;
    Course create(String id, String instructor) throws CreateException/*,RemoteException*/;
}

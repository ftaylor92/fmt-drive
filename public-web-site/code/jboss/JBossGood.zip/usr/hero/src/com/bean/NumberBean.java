package com.bean;

public class NumberBean {
   int firstNumber= 0;
   int secondNumber= 0;

   public NumberBean() {
	System.out.println("creating Object Model");
   }

   public void setFirstNumber(int number) {
	firstNumber= number;
	System.out.printf("set firstNumber %d\n", number);
   }

   public int getFirstNumber() {
	System.out.printf("get firstNumber %d\n", firstNumber);
	return firstNumber;
   }

   public void setSecondNumber(int number) {
	secondNumber= number;
	System.out.printf("set secondNumber %\n", number);
   }

   public int getSecondNumber() {
	System.out.printf("get secondNumber %d\n", secondNumber);
	return secondNumber;
   }

   public int getResult() {
	System.out.printf("get result %d\n", firstNumber+ secondNumber);
	return firstNumber+ secondNumber;
   }
}
package com;

import java.util.Iterator;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ActionListener;
import javax.faces.event.PhaseId;
//import javax.faces.tree.Tree;

public class MathActionListener implements ActionListener {
   public PhaseId getPhaseId() {
	System.out.println("getPhaseId() called");
	return PhaseId.APPLY_REQUEST_VALUES;
   }

   public void processAction(ActionEvent event) {
	/*System.out.println("processAction() called");

	UIComponent component= event.getComponent();
	System.out.println("id of component "+ component.getId());

	String actionCommand= event.getActionCommand();
	System.out.println("Action Command: "+ actionCommand);

	FacesContext facesContext= FacesContext.getCurrentInstance();
	//Tree tree= facesContext.getTree().getRoot();
	UIComponent root= facesContext.getTree().getRoot();

	System.out.println("---Component Tree---");
	navigateComponentTree(root, 0);

	System.out.println("--------------------");*/
   }

   private void navigateComponentTree(UIComponent component, int level) {
	Iterator children= component.getChildren().iterator();

	for(int i= 0; i<level; i++) {
	   System.out.println("  ");
	}

	System.out.println(component.getId());

	while(children.hasNext()) {
	   UIComponent child=(UIComponent)children.next();
	   navigateComponentTree(child, level+ 1);
	}
   }
}
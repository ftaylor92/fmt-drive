package com.ejbean;

import javax.ejb.*;
import java.lang.*;
import java.rmi.*;

/**
 *
 * @author ftaylor
 */
public interface Course extends EJBLocalObject {
    java.lang.String getCourse_Id()/* throws RemoteException*/;   //primary key
    String getInstructor() /*throws RemoteException*/;
    void setInstructor(String instructor)/* throws RemoteException*/;
    void setCourse_Id(String id)/* throws RemoteException*/;
}

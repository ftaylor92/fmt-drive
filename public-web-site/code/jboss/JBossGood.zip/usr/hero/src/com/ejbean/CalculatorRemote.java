package com.ejbean;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.ejb.EJBObject;

public interface CalculatorRemote extends EJBObject {
	public int add(int a, int b) throws RemoteException;
	public int divide(int a, int b) throws RemoteException;
	public int multiply(int a, int b) throws RemoteException;
	public int getTotal() throws RemoteException;
	public void addTo(int a) throws RemoteException;
}
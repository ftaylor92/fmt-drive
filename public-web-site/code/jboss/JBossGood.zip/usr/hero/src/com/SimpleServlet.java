package com;

import javax.servlet.http.*;
import java.io.*;

/**
 *
 * @author TaylorFM
 **/
public class SimpleServlet extends HttpServlet {
    
    /** Handle HTTP GET method by building a simple web page.
     **/
    public void doGet(HttpServletRequest resuest, HttpServletResponse response) {
        PrintWriter out;
        String title="Simple Servlet Output";
        
        response.setContentType("text/html");
        
	try {
        out= response.getWriter();
        
        out.println("<HTML><HEAD><TITLE>");
        out.println(title);
        out.println("</TITLE></HEAD><BODY>");
        out.println("<H1>"+title+"</H1>");
        out.println("This is a simple servlet.<BR />");
        out.println("</BODY></HTML>");
        out.close();
	} catch (IOException ex) {
		System.out.println(ex);
	}
    }
    
}

package com;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class BookStoreServlet extends HttpServlet {
   public synchronized void init(ServletConfig config) throws ServletException {
	super.init();
   }

   public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	res.setContentType("text/html");
	PrintWriter out= res.getWriter();

	out.println("<HTML>");
	out.println("<BODY>");
	out.println("<H1>Welcome to Bookstore</H1>");
	out.println("Would you like to begin shopping?<BR />");
	out.println("<FORM action='/game/BookStoreServlet' method='POST'>");
	out.println("<INPUT type='submit' value='You Bet!' />");
	out.println("</FORM>");
	out.println("</BODY>");
	out.println("</HTML>");

   }

   public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	StringBuffer HTML= new StringBuffer();
	res.setContentType("text/html");
	PrintWriter out= res.getWriter();
	ShoppingCart sc;
	HttpSession session= req.getSession(true);

	if(null == session.getAttribute("Cart")) {
	   sc= new ShoppingCart();
	   session.setAttribute("Cart",sc);
	   int acct= new Random().nextInt();
	   if(acct < 0) {
		acct*= -1;
	   }
	   ((ShoppingCart)session.getAttribute("Cart")).setAccountNum(acct);
	} else {
	   Enumeration pEnum= req.getParameterNames();
	   while(pEnum.hasMoreElements()) {
		String parmName= (String)pEnum.nextElement();
		if(parmName.equals("stockNum")) {
		   String parmValue= req.getParameter(parmName);
		   ((ShoppingCart)session.getAttribute("Cart")).addItem(/*parmValue*/7);
		}
	   }
	}

	out.println("Your account number is "+((ShoppingCart)session.getAttribute("Cart")).getAccountNum());
   }
}

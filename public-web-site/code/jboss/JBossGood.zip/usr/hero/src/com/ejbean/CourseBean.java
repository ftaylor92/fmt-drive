package com.ejbean;

import java.rmi.RemoteException;
import javax.ejb.RemoveException;
import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import java.sql.*;
import javax.sql.*;
import java.io.*;
import javax.naming.*;
import java.util.Locale;

/**
 *
 * @author ftaylor
 */
abstract public class CourseBean implements EntityBean {
    private Locale locale = Locale.US;
    transient private EntityContext ctx;
    
    public String id, instructor;
    
    public CourseBean() {}
    
    public void setLocale(Locale locale)
   {
      this.locale = locale;
   }

    public void ejbLoad() throws EJBException, RemoteException {
      try {
        loadRow();
      } catch (Exception ex) {
        throw new EJBException("ejbLoad: " + 
          ex.getMessage());
      }
    }
    public void ejbStore() throws EJBException, RemoteException {
      /*try {
        storeRow();
      } catch (Exception ex) {
        throw new EJBException("ejbStore: " + 
          ex.getMessage());
      }*/
    }

    public void setEntityContext(EntityContext ctx) throws EJBException, RemoteException {
            this.ctx= ctx;
            System.out.println("setEntityContext called");
    }

    public void unsetEntityContext() throws EJBException, RemoteException {
            this.ctx= null;
    }

    public void ejbRemove() throws EJBException, RemoteException, RemoveException {
    /*try {
        deleteRow(id);
    catch (Exception ex) {
        throw new EJBException("ejbRemove: " +
        ex.getMessage());
        }*/
    }

    public void ejbActivate() throws EJBException, RemoteException {
    }

    public void ejbPassivate() throws EJBException {
    }

    abstract public String getCourse_Id();/* {
            return this.id;
    }*/
    
    abstract public void setCourse_Id(String id);/* {
            this.id= id;
    }*/
    abstract public String getInstructor();/* {
            return this.instructor;
    }*/
    
    abstract public void setInstructor(String prof);/* {
            this.instructor= prof;
    }*/

    
    public String ejbCreate(String id, String prof) throws CreateException {
        this.id= id;
        this.instructor= prof;
        System.out.println("ejbPostCreate called with ID: " + id);
        /*try {
            insertRow(id, firstName, lastName, balance);
        } catch (Exception ex) {
        throw new EJBException("ejbCreate: " + 
            ex.getMessage());
        }*/

        return null;
    }    
    
    public void ejbPostCreate(String Course, String prof) throws CreateException {
    }
    
    public void loadRow() {
        try {
            InitialContext initialContext= new InitialContext();
            DataSource ds= (DataSource)initialContext.lookup("java:/MySqlDS");
            Connection conn = ds.getConnection();

            String selectStatement =
                 "select course_id,instructor " +
                 "from find_courses where course_id = ?";
            PreparedStatement prepStmt =
                 conn.prepareStatement(selectStatement);
            prepStmt.setString(1, id);

            ResultSet rs = prepStmt.executeQuery();

            if (rs.next()) {
              instructor = rs.getString("instructor");
            }
            else {
              instructor = "nobody";
            }

            prepStmt.close();
            conn.close();
        } catch(Exception ex) {
            System.out.println(ex);
        }
    }
}

package com.ejbean;

import javax.ejb.*;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import com.ejbean.CalculatorRemote;

public interface CalculatorLocal extends EJBHome {
	public CalculatorRemote create() throws RemoteException, CreateException;
}
package %CLIENT_PACKAGE%;

import java.net.URL;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
* The client service interface for the ProductReviews web
* service.
*/
public interface %SERVICE_INTERFACE_CLASS_NAME% extends Service {
    public %SEI_CLASS_NAME% getSimpleSEIPort() throws ServiceException;
}

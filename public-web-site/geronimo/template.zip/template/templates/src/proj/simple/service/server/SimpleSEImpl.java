package %SERVER_PACKAGE%;

import javax.xml.rpc.server.ServiceLifecycle;
import javax.xml.rpc.server.ServletEndpointContext;
import javax.xml.rpc.ServiceException;
import java.rmi.RemoteException;

public class %SEI_IMPLEMENTATION_NAME% implements %SEI_CLASS_NAME%
{
	public String getURL(Integer productId) throws RemoteException {
		String a= "INTRO pSYCH";
		return a;
	}

	public %DATA_1_CLASS_NAME% getReview(Integer productId, String reviewer) throws RemoteException {
		%DATA_1_CLASS_NAME% a= null;
		return a;
	}

	/*public void init(Object object) throws ServiceException {
		ServletEndpointContext ctx = (ServletEndpointContext)object;
	}
	
	public void destroy() {
	}*/
}

package utilities;

import javax.naming.NamingException;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceFactory;
import javax.xml.rpc.ServiceException;
import java.net.URL;
import java.net.MalformedURLException;
import %SEI_CLASS_CLIENT%;
import %SERVICE_INTERFACE_CLASS%;
import %CLIENT_PACKAGE%.%DATA_1_CLASS_NAME%;
import javax.xml.namespace.QName;
import java.awt.image.RenderedImage;
import java.awt.Image;
import java.io.File;
import javax.imageio.ImageIO;
import utilities.ImageUtilities;

public class Client {

	public static SimpleSEI getServiceViaProxy() throws ServiceException, MalformedURLException {
		%SEI_CLASS_NAME% sSimple= null;
		
		ServiceFactory fac= ServiceFactory.newInstance();
		URL wsdlURL= new URL("%WSDL_ADDRESS%");
		Service ots= fac.createService(wsdlURL, new QName("%TYPE_NAMESPACE%", "%SERVICE_NAME%"));
		sSimple= (%SEI_CLASS_NAME%)ots.getPort(new QName("%TYPE_NAMESPACE%", "%SERVICE_PORT%"), %SEI_CLASS_NAME%.class);

		return sSimple;
	}

	public static void main(String[] args) {
		try {
			%SEI_CLASS_NAME% sSimple= Client.getServiceViaProxy();
			
			String theURL = sSimple.getURL(Integer.valueOf("33"));
			
			Image theJPG= sSimple.getImage("http://www.smugmug.com/photos/45595589-Ti-2.jpg");
			if(theJPG != null) {
				ImageUtilities.writeImage(theJPG, "C:/usr/tmp/aPict.jpg");
			}
			System.out.println("Service result: "+ theURL);
		} catch (Exception ex) {
			System.err.println(ex);
		}
	}
}
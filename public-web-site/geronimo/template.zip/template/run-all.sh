#! /usr/bin/sh

#Automatic Web Services deployer

#removes any running instances of web-app from Geronimo
ant undeploy
#removes old files
ant clean
#removes old directories not usually created
rm -r {src-gen,reviews}
#creates necessary directories for building
mkdir {src-gen,bin}
#copies tampled files to normal positions and changes key-words
ant template
#compiles few files neccessary for WSDL generation
ant compile-pre-wsdl
#creates WSDL
C:/usr/bin/Sun/jwsdp-2.0/jaxrpc/bin/wscompile.bat -cp ./bin -gen:server -f:strict -f:documentliteral ./tools/config-wsdl.xml
#adds URL to WSDL and moves WSDL
#egrep 'service name' *.wsdl | sed -r 's/.*<service name="(.*)">/%SERVICE_NAME%\t\1/g' >> ./templates/variables.properties
egrep 'port name' *.wsdl | sed -r 's/.*<port name="([a-zA-Z0-9]*)"(.*>)/%SERVICE_PORT%\t\1/g' >> ./templates/variables.properties
mv ProductReviewService.wsdl ./web/WEB-INF/wsdl/ISimpleService.wsdl
ant template-wsdl

#re-makes neccessary directories for building
mkdir src-gen
#creates client code
C:/usr/bin/Sun/jwsdp-2.0/jaxrpc/bin/wscompile.bat -s src-gen -keep -mapping ./web/WEB-INF/client-mapping.xml -cp ./bin -gen:client -f:strict -f:documentliteral ./tools/config-mapping-client.xml
#creates server code
C:/usr/bin/Sun/jwsdp-2.0/jaxrpc/bin/wscompile.bat -s src-gen -keep -mapping ./web/WEB-INF/server-mapping.xml -cp ./bin -gen:server -f:strict -f:documentliteral ./tools/config-mapping-server.xml
#compiles, packages and deploys web-app
ant clean compile war deploy

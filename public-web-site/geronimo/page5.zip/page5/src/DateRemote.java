package test.ejb;

public interface DateRemote extends javax.ejb.EJBObject {
  public String getDate() throws java.rmi.RemoteException;
}
package test.ejb;

public interface DateLocal extends javax.ejb.EJBLocalObject {
  //public String getDate() throws java.rmi.RemoteException;
}
package test.ejb;

public interface DateHome extends javax.ejb.EJBHome {
    DateRemote create() throws java.rmi.RemoteException,
        javax.ejb.CreateException;
}
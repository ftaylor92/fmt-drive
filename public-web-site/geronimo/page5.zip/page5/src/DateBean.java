package test.ejb;

public class DateBean implements javax.ejb.SessionBean {
    public void ejbCreate() { }
    public void ejbRemove() { }
    public void ejbActivate() { }
    public void ejbPassivate() { }
    public void setSessionContext(javax.ejb.SessionContext ctx) { }

    public String getDate() {
	java.util.List<String> dates= new java.util.ArrayList<String>();
	dates.add(new java.util.Date().toString());
	dates.add("EST=");
        return ("Hello Brooklyn");
    }
}